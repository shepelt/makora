import { Muya } from '../../index';
import { IBaseOptions, IShortcutHintOptions } from '../types';
import { default as BaseFloat } from '../baseFloat';
export declare class ParagraphFrontMenu extends BaseFloat {
    static pluginName: string;
    capturesContentKeydown: boolean;
    private _oldVNode;
    private _block;
    private _frontMenuContainer;
    protected options: IBaseOptions & IShortcutHintOptions;
    constructor(muya: Muya, options?: Partial<IBaseOptions> & IShortcutHintOptions);
    listen(): void;
    private _renderSubMenu;
    private _renderCopyAs;
    render(): void;
    selectItem(event: Event, { label }: {
        label: string;
    }): void;
    private _applyMetaAction;
    private _turnIntoBlock;
    private _turnIntoList;
}
