import { default as Parent } from '../../block/base/parent';
import { CopyType } from '../../clipboard/types';
export declare const FRONT_MENU: {
    icon: any;
    label: string;
    text: string;
    shortCut: string;
}[];
export declare const COPY_AS: {
    icon: any;
    label: string;
    text: string;
};
export declare const COPY_AS_MENU: {
    label: string;
    text: string;
    copyType: CopyType;
}[];
export type FrontMenuIcon = (typeof FRONT_MENU)[number];
export declare function canTurnIntoMenu(block: Parent): {
    title: string;
    subTitle: string;
    label: string;
    icon: string;
    score?: number;
    i18nTitle?: string;
    searchText?: string;
    shortCut?: string;
    shortKeyMap?: {
        altKey: boolean;
        shiftKey: boolean;
        metaKey: boolean;
        code: string;
    };
}[];
