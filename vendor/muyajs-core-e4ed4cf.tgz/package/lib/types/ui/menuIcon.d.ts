export declare function renderMenuIcon({ label, icon }: {
    label: string;
    icon: string;
}): import('snabbdom').VNode;
