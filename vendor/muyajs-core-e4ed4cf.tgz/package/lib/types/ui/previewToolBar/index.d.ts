import { Muya } from '../../index';
import { IPreviewToolIcon } from './config';
import { default as BaseFloat } from '../baseFloat';
export interface IPreviewDiagramPayload {
    type: string;
    code: string;
    preview: HTMLElement;
    label: string | null;
}
export declare class PreviewToolBar extends BaseFloat {
    static pluginName: string;
    private _oldVNode;
    private _block;
    private _iconContainer;
    constructor(muya: Muya, options?: {});
    listen(): void;
    hide(): void;
    private _tuckInsideBlock;
    private _previewNode;
    private _items;
    render(): void;
    selectItem(event: Event, i: IPreviewToolIcon): void;
}
