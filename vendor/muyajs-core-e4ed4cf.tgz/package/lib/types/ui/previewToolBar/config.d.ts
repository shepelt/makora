export type TPreviewToolType = 'view' | 'edit' | 'delete';
export interface IPreviewToolIcon {
    type: TPreviewToolType;
    tooltip: string;
    icon: string;
    blocks?: ReadonlySet<string>;
    requiresRender?: boolean;
}
export declare const PREVIEW_BLOCK_NAMES: ReadonlySet<string>;
export declare function previewToolBarItems(blockName: string, hasRenderedMedia: boolean): IPreviewToolIcon[];
