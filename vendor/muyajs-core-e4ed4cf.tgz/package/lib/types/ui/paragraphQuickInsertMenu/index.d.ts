import { VNode } from 'snabbdom';
import { Muya } from '../../index';
import { IBaseOptions, IKeyboardShortcutOptions } from '../types';
import { IQuickInsertMenuItem } from './config';
import { default as BaseScrollFloat } from '../baseScrollFloat';
export declare class ParagraphQuickInsertMenu extends BaseScrollFloat {
    static pluginName: string;
    capturesContentKeydown: boolean;
    oldVNode: VNode | null;
    private _block;
    activeItem: IQuickInsertMenuItem['children'][number] | null;
    renderArray: IQuickInsertMenuItem['children'];
    private _renderData;
    protected options: IBaseOptions & IKeyboardShortcutOptions;
    constructor(muya: Muya, options?: Partial<IBaseOptions> & IKeyboardShortcutOptions);
    get renderData(): IQuickInsertMenuItem[];
    set renderData(data: IQuickInsertMenuItem[]);
    listen(): void;
    step(direction: 'previous' | 'next'): void;
    hide(): void;
    render(): void;
    private _search;
    selectItem({ label }: IQuickInsertMenuItem['children'][number]): void;
    getItemElement(item: IQuickInsertMenuItem['children'][number]): HTMLElement | null;
}
