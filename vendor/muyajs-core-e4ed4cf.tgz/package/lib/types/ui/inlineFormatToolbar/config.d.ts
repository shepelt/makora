import { ColorFormatType } from '../../utils/colorSpan';
declare const icons: {
    type: string;
    tooltip: string;
    shortcut: string;
    icon: any;
}[];
export type FormatToolIcon = typeof icons[number];
export interface IColorSwatch {
    /** `#rrggbb`, or `null` for the default / no-colour swatch. */
    value: string | null;
    label: string;
}
export interface IColorSection {
    type: ColorFormatType;
    title: string;
    swatches: IColorSwatch[];
}
export declare const TEXT_COLOR_SWATCHES: IColorSwatch[];
export declare const BACKGROUND_COLOR_SWATCHES: IColorSwatch[];
export declare const COLOR_SECTIONS: IColorSection[];
export default icons;
