declare function getClassByName(name: string): string | null;
declare function getClassByLanguage(lang: string): string | null;
declare const _default: {
    getClassByName: typeof getClassByName;
    getClassByLanguage: typeof getClassByLanguage;
};
export default _default;
