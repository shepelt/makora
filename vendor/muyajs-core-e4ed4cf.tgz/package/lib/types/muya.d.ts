import { default as Content } from './block/base/content';
import { default as Parent } from './block/base/parent';
import { IHeadingFoldState } from './block/folding';
import { Listener, TEventListener } from './event/types';
import { ILocale } from './i18n/types';
import { IReplaceOption, ISearchOption } from './search/types';
import { IIndexCursor } from './selection/offsetCursor';
import { TSelectionState } from './selection/types';
import { ITocItem } from './state/getTOC';
import { TState } from './state/types';
import { IMuyaOptions, Nullable } from './types';
import { Editor } from './editor/index';
import { default as EventCenter } from './event/index';
import { default as I18n } from './i18n/index';
import { Ui } from './ui/ui';
export interface IMuyaPluginConstructor {
    pluginName: string;
    new (muya: Muya, options: Record<string, unknown>): unknown;
}
interface IPlugin {
    plugin: IMuyaPluginConstructor;
    options: Record<string, unknown>;
}
export declare class Muya {
    static plugins: IPlugin[];
    static use(plugin: IMuyaPluginConstructor, options?: Record<string, unknown>): void;
    readonly version: string;
    options: IMuyaOptions;
    eventCenter: EventCenter;
    domNode: HTMLElement;
    editor: Editor;
    ui: Ui;
    i18n: I18n;
    private _uiPlugins;
    private _documentUpdateDepth;
    private _cancelReadingLink;
    get isReadOnly(): boolean;
    get canMutate(): boolean;
    isBlockInDocument(block: Nullable<Content | Parent>): boolean;
    /** Host content loads may replace a locked document; user commands cannot. */
    runDocumentUpdate<T>(update: () => T): T;
    setReadOnly(readOnly: boolean): void;
    constructor(element: HTMLElement, options?: Partial<IMuyaOptions>);
    private _refreshReadingPresentation;
    private _bindFocusBlurEvents;
    init(options?: {
        focus?: boolean;
    }): void;
    /** Repaint host-owned shortcut hints without changing document or selection state. */
    refreshShortcutHints(): void;
    locale(object: ILocale): void;
    on<K extends string>(event: K, listener: TEventListener<K>): void;
    off(event: string, listener: Listener): void;
    once<K extends string>(event: K, listener: TEventListener<K>): void;
    getState(): TState[];
    getMarkdown(): string;
    flush(): void;
    /** Group synchronous Block commands into one completed edit transaction. */
    transact<T>(command: () => T): T;
    /** The conversion must activate its result so selection endpoints can be mapped in the same transaction. */
    withPreservedSelection(command: () => void): void;
    getTOC(): ITocItem[];
    /** Capture transient section folds before switching documents. */
    getHeadingFoldState(): IHeadingFoldState[];
    /** Restore a snapshot only after loading the same document structure. */
    setHeadingFoldState(state: IHeadingFoldState[]): void;
    undo(): void;
    redo(): void;
    getHistory(): import('./history').ISerializedHistory;
    setHistory(history: ReturnType<Muya['getHistory']>): void;
    clearHistory(): void;
    /** Reveal an editor element before the host measures it for scrolling. */
    revealElement(element: Element): void;
    search(value: string, opts?: ISearchOption): import('./search').Search;
    find(action: 'previous' | 'next'): import('./search').Search;
    setSearchVisible(visible: boolean): import('./search').Search;
    replace(replaceValue: string, opt?: IReplaceOption): import('./search').Search | undefined;
    setContent(content: TState[] | string, autoFocus?: boolean): void;
    /**
     * Replace the document as one undo step, preserving existing history.
     * No-op when the content is unchanged.
     *
     * `recordSelection` is the selection restored by undo. Omit it to use the
     * live selection, or pass the saved WYSIWYG selection when focus has moved
     * to source mode.
     *
     * @returns Whether an undo boundary was recorded.
     */
    replaceContent(content: TState[] | string, recordSelection?: Nullable<TSelectionState>): boolean;
    setOptions(options: Partial<IMuyaOptions>, forceRender?: boolean): void;
    private _prepareDocumentRebuild;
    private _forceRender;
    private _renderDocument;
    setListIndentation(listIndentation: IMuyaOptions['listIndentation']): void;
    focus(): void;
    setFocusMode(focusMode: boolean): void;
    selectAll(): void;
    format(type: string): void;
    private _formatAcrossBlocks;
    private _orderedSelectionRange;
    /**
     * Apply `type` to one leaf over [start, end), skipping non-formattable
     * leaves and heading delimiters. Returns the leaf's selection
     * range AFTER formatting (offsets shift past inserted markers), or null when
     * the leaf was skipped.
     */
    private _formatLeafInRange;
    private _headingBodyRange;
    /**
     * Replace only when the word at the cursor still matches `word`, then move
     * the cursor after the replacement. Returns whether it was applied.
     */
    replaceCurrentWordInlineUnsafe(word: string, replacement: string): boolean;
    getSelection(): import('.').TSelection | null;
    getSelectionState(): TSelectionState | null;
    setSelection(state: TSelectionState | null): boolean;
    /**
     * Selected source text; table rectangles use tabs between cells and newlines
     * between rows. Object-selected images and null selections return an empty string.
     */
    getSelectedText(): string;
    hasFocus(): boolean;
    /**
     * Blur the editor. Always hides every floating tool and blurs the
     * contenteditable node.
     * @param isRemoveAllRange Remove all native selection ranges.
     * @param unSelect Clear the selected inline image so its toolbar/resize
     * bar do not linger after the editor is blurred.
     */
    blur(isRemoveAllRange?: boolean, unSelect?: boolean): void;
    hideAllFloatTools(): void;
    /** Reload images whose files changed on disk despite cached bitmaps. */
    invalidateImageCache(): void;
    copyAsMarkdown(): void;
    /** Copy rendered HTML as literal markup in the plain-text clipboard slot. */
    copyAsHtml(): void;
    /** Copy rendered HTML as rich text, with Markdown as the plain-text fallback. */
    copyAsRich(): void;
    pasteAsPlainText(): Promise<void>;
    /** Insert a file path or data URL through the configured `imageAction`. */
    pasteImage(src: string): Promise<void>;
    private _outmostBlockAtCursor;
    private _immediateBlockAtCursor;
    /**
     * Cross-block paragraph-menu handling: a selection that spans several
     * outmost blocks wraps each block into one list item. Returns true when the
     * operation was handled so the single-block path is skipped. Quote/code and
     * other cross-block targets are gated by the menu layer and fall through.
     */
    private _handleCrossBlockParagraph;
    /** Prefer cross-block endpoints when the live range collapses during a menu/IPC round-trip. */
    private _selectionEndpoints;
    private _selectionInSameBlock;
    /** Nested paragraphs share an outmost block but need separate inline formatting (#3462). */
    private _selectionInSameLeaf;
    /** ScrollPage children covered by the selection, in document order. */
    private _selectedOutmostBlocks;
    /**
     * Select the full span of a freshly-wrapped container (first content leaf to
     * last) so the selection keeps covering the wrapped content. Best-effort.
     */
    private _selectWrappedContent;
    /** Replace selected outmost blocks with one container, then restore the selection via `place`. */
    private _wrapSelectedBlocks;
    private _getStateForWrapping;
    private _wrapSelectedBlocksInList;
    private _wrapSelectedBlocksInQuote;
    /** Join the selected outmost blocks' text into a single fenced code block. */
    private _wrapSelectedBlocksInCodeBlock;
    /**
     * Duplicate the block at the current cursor, placing the cursor in the
     * copy. No-op when there is no current block.
     */
    duplicate(): void;
    /**
     * Insert an empty paragraph relative to the block at the current cursor.
     * @param location Insert `before` or `after` the current block (default `after`).
     * @param text Initial text of the new paragraph.
     * @param outMost When `true`, anchor the new paragraph to the OUTERMOST
     *   container (the legacy "Create Paragraph Below" behaviour). When `false`
     *   (default), anchor to the IMMEDIATE block at the cursor so the paragraph
     *   stays as an inner sibling inside a list item / blockquote — the legacy
     *   context-menu "Insert Paragraph Before/After" behaviour.
     */
    insertParagraph(location?: 'before' | 'after', text?: string, outMost?: boolean): void;
    private _insertParagraph;
    /**
     * Delete the block at the current cursor, moving the cursor to an adjacent
     * block, or to a fresh empty paragraph when it was the only block.
     */
    deleteParagraph(): void;
    private _deleteParagraph;
    /**
     * Insert a table at `block` (default: the block holding the caret): in its
     * place when it is empty or `replace` is set, otherwise directly below it.
     * No-op when that block is no longer in the document.
     */
    createTable({ rows, columns }: {
        rows: number;
        columns: number;
    }, { replace, block }?: {
        replace?: boolean;
        block?: Parent | null;
    }): void;
    /**
     * Insert an inline image in a formattable block; no-op elsewhere.
     * Selected text takes precedence over `alt`; otherwise an empty alt uses the file name.
     */
    insertImage({ src, alt }: {
        src?: string;
        alt?: string;
    }): void;
    /**
     * Restore a source-mode line/ch cursor without changing the document or
     * undo history. Returns false when the cursor cannot be resolved.
     */
    setCursorByOffset(indexCursor: IIndexCursor): boolean;
    /**
     * Read the selection as source-mode line/ch positions without changing the
     * document or undo history. Returns null when it cannot be located.
     */
    getCursorOffset(): IIndexCursor | null;
    private _handleGithubAlertParagraph;
    /**
     * Convert the block at the cursor to another type. `type` uses the
     * paragraph-menu
     * vocabulary: `paragraph`, `heading 1`–`heading 6`, `upgrade heading`,
     * `degrade heading`, `blockquote`, `pre`, `mathblock`, `html`, `hr`,
     * `table`, `front-matter`, `ul-bullet`/`ol-order`/`ul-task`,
     * `loose-list-item`, `reset-to-paragraph`, and the diagram types.
     */
    updateParagraph(type: string): void;
    private _updateParagraph;
    /**
     * Toggle off a matching type, unwrapping all same-kind ancestors so the menu
     * item becomes unchecked. Headings match only at the requested level.
     * Returns whether a matching type was found.
     */
    private _toggleIfActive;
    private _closestListAtCursor;
    /** Conversions must leave the caret content active so its selection can be restored. */
    private _withPreservedOffset;
    /** Skip marker-only leaves so restoring a caret cannot land on an unrelated code/math block. */
    private _findContentByText;
    /** Preserve enclosing lists/quotes when converting their inner paragraph or heading. */
    private _convertOrInsertBelow;
    /**
     * Unwrap lists and quotes without losing children; leave tables untouched.
     * Other blocks become paragraphs carrying their leading text.
     */
    resetToParagraph(block: Parent): void;
    /** Preserve raw code, discard thematic-break markers, and strip heading hashes. */
    private _paragraphTextFor;
    /** Convert the inner block without unwrapping its enclosing list or quote. */
    private _convertLeafToParagraph;
    /**
     * Unwrap a structured container (list or blockquote) into the top-level
     * blocks it contains, preserving every item.
     */
    private _unwrapToParagraphs;
    private _blockLeadingText;
    private _changeHeadingLevel;
    private _toggleLooseList;
    private _convertListType;
    destroy(): void;
}
export {};
