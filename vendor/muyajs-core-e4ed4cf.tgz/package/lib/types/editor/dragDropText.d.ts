import { default as Content } from '../block/base/content';
import { Muya } from '../muya';
import { IAnchorFocusInfo, ITextSelectionState } from '../selection/types';
export interface ITextDragSource {
    block: Content;
    start: number;
    end: number;
    original: string;
    selection: ITextSelectionState;
}
export declare function getTextDragSource(muya: Muya): ITextDragSource | null;
export declare function canDropText(muya: Muya, source: ITextDragSource, target: IAnchorFocusInfo, copy: boolean): boolean;
export declare function dropText(muya: Muya, source: ITextDragSource, target: IAnchorFocusInfo, copy: boolean): void;
export declare class TextDrag {
    private _muya;
    private _eventIds;
    private _source;
    private _origin;
    private _point;
    private _dragging;
    private _suppressClick;
    private _copy;
    private _cursor;
    private _scroll;
    private _preview;
    private _indicator;
    constructor(_muya: Muya);
    get isDragging(): boolean;
    destroy(): void;
    private _blur;
    private _readOnlyChanged;
    private _jsonChanged;
    cancel(restore?: boolean): void;
    private _down;
    private _move;
    private _key;
    private _up;
    private _overlay;
    private _restoreScroll;
    private _paint;
}
