import { JSONOp } from 'ot-json1';
import { default as Content } from '../block/base/content';
import { Muya } from '../muya';
import { TSelectionState } from '../selection/types';
import { TState } from '../state/types';
import { Nullable, ChangeSource } from '../types';
import { ITransactionOptions, EditTransactions } from './transactions';
import { ScrollPage } from '../block/scrollPage';
import { default as Clipboard } from '../clipboard';
import { default as History } from '../history';
import { default as InlineEngine } from '../inline';
import { Search } from '../search';
import { default as Selection } from '../selection';
import { default as JSONState } from '../state';
import { TextDrag } from './dragDropText';
export declare class Editor {
    private _muya;
    jsonState: JSONState;
    transactions: EditTransactions;
    isUpdating: boolean;
    get isComposing(): boolean;
    inlineEngine: InlineEngine;
    selection: Selection;
    searchModule: Search;
    clipboard: Clipboard;
    history: History;
    scrollPage: Nullable<ScrollPage>;
    textDrag: TextDrag | null;
    private _activeContentBlock;
    private _inputSelection;
    private _isComposing;
    constructor(_muya: Muya);
    get activeContentBlock(): Nullable<Content>;
    set activeContentBlock(block: Nullable<Content>);
    init(options?: {
        focus?: boolean;
    }): void;
    private _dispatchEvents;
    private _isContentEvent;
    private _dispatchContentEvent;
    private _getPreviewClickTarget;
    private _handlePreviewClick;
    focus(): void;
    transact<T>(command: () => T, isolated?: boolean, recordSelection?: Nullable<TSelectionState>): T;
    updateContents(operation: JSONOp, selection: Nullable<TSelectionState>, source: ChangeSource): void;
    replayContents(operation: JSONOp, selection: Nullable<TSelectionState>, rebuild?: boolean): void;
    private _commitTransaction;
    private _updateBlocks;
    private _restoreSelection;
    /**
     * Apply a history op by rebuilding the live block tree wholesale instead of
     * walking it incrementally (`updateContents`). The op is dispatched to the
     * authoritative json state, then `ScrollPage.updateState` re-creates the DOM
     * from that state — the same safe path `setContent` uses. Used for undo/redo
     * of whole-document boundaries (e.g. exiting source-code mode) whose op
     * shapes the incremental pick/drop walker cannot apply without desyncing the
     * DOM from the json state.
     */
    rebuildContents(operation: JSONOp, selection: Nullable<TSelectionState>, source: ChangeSource, options?: ITransactionOptions): void;
    setContent(content: TState[] | string, autoFocus?: boolean): void;
}
