import { JSONOp } from 'ot-json1';
import { TState } from '../../state/types';
import { IMuyaOptions } from '../../types';
/** Promote affected logical lists; authored loose spacing is never tightened. */
export declare function listLoosenessOperations(previous: readonly TState[], root: readonly TState[], op: JSONOp, options: IMuyaOptions): null;
