import { Doc, JSONOp, Path } from 'ot-json1';
import { TSelectionState } from '../../selection/types';
import { default as JSONState } from '../../state';
import { TState } from '../../state/types';
import { IMuyaOptions, Nullable, ChangeSource } from '../../types';
import { TDiff } from '../../utils';
export interface ITransactionOptions {
    source?: ChangeSource;
    selection?: Nullable<TSelectionState>;
    view?: 'incremental' | 'rebuild';
    history?: 'merge' | 'isolated' | 'separate' | 'ignore';
    replay?: boolean;
    recordSelection?: Nullable<TSelectionState>;
}
export interface ICompletedTransaction extends Required<Omit<ITransactionOptions, 'recordSelection' | 'view'>> {
    view: 'incremental' | 'rebuild' | 'mutated';
    operation: JSONOp;
    blockOperation: JSONOp;
    recordSelection?: Nullable<TSelectionState>;
}
/**
 * Collect live Block mutations and complete editing rules before committing.
 * Explicit scopes nest; unscoped DOM mutations share the next frame. Replay
 * commits recorded operations verbatim, independent of current preferences.
 */
export declare class EditTransactions {
    private _state;
    private _options;
    private _commit;
    private _rollback;
    private _applyPending;
    private _getSelection;
    private _pending;
    private _pendingSource;
    private _candidate;
    private _pendingHistory;
    private _recordSelection;
    private _rafId;
    private _depth;
    private _failed;
    private _error;
    constructor(_state: JSONState, _options: () => IMuyaOptions, _commit: (transaction: ICompletedTransaction) => void, _rollback: () => void, _applyPending: (operation: JSONOp, options: ITransactionOptions, preview: readonly TState[]) => void, _getSelection?: () => Nullable<TSelectionState>);
    /** Read-only document for rendering live edits before the scope commits. */
    get candidateState(): readonly TState[];
    get isActive(): boolean;
    captureSelection(): void;
    /** Synchronous Block commands form one commit, including nested commands. */
    run<T>(command: () => T, isolated?: boolean, selection?: Nullable<TSelectionState>): T;
    enqueue(operation: JSONOp, source?: ChangeSource): void;
    insertOperation(path: Path, state: TState): void;
    removeOperation(path: Path): void;
    editOperation(path: Path, diff: TDiff[]): void;
    replaceOperation(path: Path, before: Doc, after: Doc): void;
    insertValueOperation(path: Path, value: Doc): void;
    /** Operations inside a scope join it; standalone operations flush earlier edits first. */
    apply(operation: JSONOp, options?: ITransactionOptions): void;
    flush(): void;
    /** Discard pending edits when replacing or destroying the document. */
    cancel(): void;
    /** History and document replacement are standalone transaction boundaries. */
    assertStandalone(): void;
    private _complete;
}
