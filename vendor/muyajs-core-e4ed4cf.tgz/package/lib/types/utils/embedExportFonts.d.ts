export declare function embedExportFonts(css: string): string;
