import { Config, DOMPurify as IDOMPurify } from 'dompurify';
declare const sanitize: IDOMPurify['sanitize'];
declare const addHook: {
    (entryPoint: "beforeSanitizeElements" | "afterSanitizeElements" | "uponSanitizeShadowNode", hookFunction: import('dompurify').NodeHook): void;
    (entryPoint: "beforeSanitizeAttributes" | "afterSanitizeAttributes", hookFunction: import('dompurify').ElementHook): void;
    (entryPoint: "beforeSanitizeShadowDOM" | "afterSanitizeShadowDOM", hookFunction: import('dompurify').DocumentFragmentHook): void;
    (entryPoint: "uponSanitizeElement", hookFunction: import('dompurify').UponSanitizeElementHook): void;
    (entryPoint: "uponSanitizeAttribute", hookFunction: import('dompurify').UponSanitizeAttributeHook): void;
}, isValidAttribute: (tag: string, attr: string, value: string) => boolean, removeHook: {
    (entryPoint: "beforeSanitizeElements" | "afterSanitizeElements" | "uponSanitizeShadowNode", hookFunction?: import('dompurify').NodeHook): import('dompurify').NodeHook | undefined;
    (entryPoint: "beforeSanitizeAttributes" | "afterSanitizeAttributes", hookFunction?: import('dompurify').ElementHook): import('dompurify').ElementHook | undefined;
    (entryPoint: "beforeSanitizeShadowDOM" | "afterSanitizeShadowDOM", hookFunction?: import('dompurify').DocumentFragmentHook): import('dompurify').DocumentFragmentHook | undefined;
    (entryPoint: "uponSanitizeElement", hookFunction?: import('dompurify').UponSanitizeElementHook): import('dompurify').UponSanitizeElementHook | undefined;
    (entryPoint: "uponSanitizeAttribute", hookFunction?: import('dompurify').UponSanitizeAttributeHook): import('dompurify').UponSanitizeAttributeHook | undefined;
};
export { addHook, Config, isValidAttribute, removeHook };
export default sanitize;
