export interface ILangLoadStatus {
    lang: string;
    status: 'noexist' | 'cached' | 'loaded';
}
export declare const loadedLanguages: Set<string>;
export declare function transformAliasToOrigin(langs: string[]): string[];
interface IPrismLike {
    languages: Record<string, unknown>;
}
declare function initLoadLanguage(Prism: IPrismLike): (langs?: string[] | string) => Promise<ILangLoadStatus[]>;
export default initLoadLanguage;
