import { default as Prism } from 'prismjs';
import { loadedLanguages, transformAliasToOrigin } from './loadLanguage';
declare const prism: typeof Prism;
declare const loadLanguage: (langs?: string[] | string) => Promise<import('./loadLanguage').ILangLoadStatus[]>;
declare function search(text: string): {
    [key: string]: string;
    name: string;
}[];
export declare function patchLatexEscapedPercent(prismInstance: typeof Prism): void;
export { walkTokens } from './walkToken';
export { loadedLanguages, loadLanguage, search, transformAliasToOrigin };
export default prism;
