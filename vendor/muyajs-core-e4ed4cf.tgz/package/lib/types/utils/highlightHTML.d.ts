import { IHighlight } from '../inline/model/types';
export declare const MARKER_HASH: {
    '<': string;
    '>': string;
    '"': string;
    '\'': string;
};
export declare function getHighlightHtml(text: string, highlights: IHighlight[], escape?: boolean): string;
