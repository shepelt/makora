export interface IDelimiterSpan {
    start: number;
    end: number;
    markerLength: number;
}
export interface IDelimiterRun {
    char: string;
    length: number;
    left: number;
    right: number;
    canOpen: boolean;
    canClose: boolean;
}
export declare function delimiterFlanking(char: string, before: string, after: string, cjkEmphasis?: boolean): {
    canOpen: boolean;
    canClose: boolean;
};
/** Reads a full code point before a UTF-16 offset; empty at the start. */
export declare function codePointBefore(s: string, i: number): string;
/** Reads a full code point at a UTF-16 offset; undefined past the end. */
export declare function codePointCharAt(s: string, i: number): string | undefined;
export declare function isCjkLabelCloser(src: string, start: number, end: number): boolean;
/** Consumes caller-owned run bounds; returned spans retain offsets in the original source. */
export declare function pairDelimiters(runs: IDelimiterRun[], offset?: number): Map<number, IDelimiterSpan>;
