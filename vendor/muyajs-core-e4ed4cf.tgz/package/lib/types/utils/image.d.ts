import { HTMLTagToken, ImageToken, Token } from '../inline/model/types';
export type TSelectableImageToken = ImageToken | (HTMLTagToken & {
    tag: 'img';
    kind?: 'tag';
});
export interface IImageInfo {
    token: TSelectableImageToken;
    imageId: string;
}
export declare function isImageToken(token: Token | undefined): token is TSelectableImageToken;
export declare function getImageInfo(image: HTMLElement): IImageInfo;
export declare function getImageSrc(src: string): {
    isUnknownType: boolean;
    src: string;
};
export declare function usesDefaultObjectSize(width?: number, height?: number): boolean;
export declare function loadImage(url: string, detectContentType?: boolean): Promise<{
    url: string;
    width: number;
    height: number;
}>;
export declare function checkImageContentType(url: string): Promise<boolean | null>;
export declare function encodeImageSrc(src: string): string;
export declare function imageToMarkdown({ src, alt, title }: {
    src: string;
    alt?: string;
    title?: string;
}): string;
export declare function correctImageSrc(src: string): string;
