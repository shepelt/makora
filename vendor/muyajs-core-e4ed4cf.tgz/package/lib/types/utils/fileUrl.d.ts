export declare const ABSOLUTE_LOCAL_REG: RegExp;
export declare function resolveRelativePath(base: string, relative: string): string;
export declare function encodeDirnameForUrl(dirname: string): string;
export declare function localPathToFileUrl(src: string): string;
export declare function resolveExportImageSrc(src: string): string;
