import { Diff } from 'fast-diff';
import { default as Content } from '../block/base/content';
import { Config } from './dompurify';
interface IUnion {
    start: number;
    end: number;
    active?: boolean;
}
type Constructor = new (...args: never[]) => object;
interface IDefer<T> {
    resolve: (value: T) => void;
    reject: (reason?: unknown) => void;
    promise: Promise<T>;
}
export declare function uniqueIdGenerator(): Generator<number, void, unknown>;
export declare const getUniqueId: () => string;
export declare function getLongUniqueId(): string;
export declare function noop(): void;
export declare const identity: <T>(i: T) => T;
export declare const isOdd: (n: number) => boolean;
export declare const isEven: (n: number) => boolean;
export declare const isLengthEven: (str?: string) => boolean;
export declare function snakeToCamel(name: string): string;
export declare function firstWordOfInfo(info: string): string;
export interface IFenceLine {
    fenceChar: '`' | '~';
    fenceLength: number;
    info: string;
}
export declare function parseFenceLine(text: string): IFenceLine | null;
export declare function conflict(arr1: [number, number], arr2: [number, number]): boolean;
export declare function union({ start: tStart, end: tEnd }: IUnion, { start: lStart, end: lEnd, active }: IUnion): {
    start: number;
    end: number;
    active: boolean | undefined;
} | null;
export declare function throttle<TArgs extends unknown[], TReturn>(func: (...args: TArgs) => TReturn, wait?: number): ((...args: TArgs) => TReturn | undefined) & {
    cancel: () => void;
};
export declare function deepClone<T>(value: T): T;
export declare function escapeHTML(str: string): string;
export declare function unescapeHTML(str: string): string;
export declare function escapeInBlockHtml(html: string): string;
export declare function wordCount(markdown: string): {
    word: number;
    paragraph: number;
    character: number;
    all: number;
};
export declare function sanitize(html: string, purifyOptions: Config, disableHtml: boolean): string;
export declare function getParagraphReference(ele: HTMLElement, id: string): {
    getBoundingClientRect(): {
        x: number;
        y: number;
        left: number;
        top: number;
        bottom: number;
        height: number;
        width: number;
        right: number;
    };
    clientWidth: number;
    clientHeight: number;
    id: string;
};
export interface IGraphemeCluster {
    /** Offset of the cluster's first UTF-16 code unit. */
    start: number;
    /** Offset just past the cluster's last UTF-16 code unit. */
    end: number;
}
export declare function graphemeClusters(text: string): Generator<IGraphemeCluster>;
export declare function firstGraphemeLength(text: string): number;
export declare function lastGraphemeLength(text: string): number;
export type TDiff = (string | number | {
    d: string;
});
export declare function diffToTextOp(diffs: Diff[]): TDiff[];
export declare function lineBounds(text: string, offset: number): [number, number];
export declare function adjustOffset<T extends Content>(offset: number, block: T, event: KeyboardEvent): number;
export declare function verticalPositionInRect(event: MouseEvent, rect: DOMRect): "up" | "down";
export declare function hasPick(c: {
    p?: number;
    r?: unknown;
} | null | undefined): boolean;
export declare function getDefer<T>(): IDefer<T>;
export declare function methodMixins(...objects: Record<string, (...args: never[]) => unknown>[]): (constructor: Constructor) => void;
export declare function mixins(...constructors: Constructor[]): (derivedCtor: Constructor) => void;
export declare function isKeyboardEvent(event: Event): event is KeyboardEvent;
export declare function isMouseEvent(event: Event): event is MouseEvent;
export declare function isInputEvent(event: Event): event is InputEvent;
export declare function isCompositionEndEvent(event: Event): event is CompositionEvent;
export declare function isElement(node: Node): node is Element;
export declare function isClipboardEvent(event: Event): event is ClipboardEvent;
export declare function isHTMLElement(value: unknown): value is HTMLElement;
export declare function isHTMLInputElement(value: unknown): value is HTMLInputElement;
export declare function isHTMLTextAreaElement(value: unknown): value is HTMLTextAreaElement;
export declare function isHTMLAnchorElement(value: unknown): value is HTMLAnchorElement;
export {};
