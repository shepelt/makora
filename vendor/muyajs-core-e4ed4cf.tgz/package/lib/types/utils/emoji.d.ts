export declare function validEmoji(text: string): {
    emoji: string;
    description: string;
    category: string;
    aliases: string[];
    tags: string[];
    skin_tones?: undefined;
} | {
    emoji: string;
    description: string;
    category: string;
    aliases: string[];
    tags: string[];
    skin_tones: boolean;
} | undefined;
export declare function checkEditEmoji(node: HTMLElement): false | HTMLElement;
