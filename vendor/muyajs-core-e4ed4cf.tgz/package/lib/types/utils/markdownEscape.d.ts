export declare const ASCII_PUNCTUATION: RegExp;
export declare const CHARACTER_REFERENCE: RegExp;
/** Accepts one complete reference matching CHARACTER_REFERENCE. */
export declare function decodeCharacterReference(reference: string): string;
/** Decode once: escaped ampersands and decoded backslashes cannot introduce another escape. */
export declare function decodeMarkdownString(text: string): string;
export declare function escapeLinkAttribute(text: string): string;
export declare function encodeLinkTitle(title: string): string;
export declare function isPunctuationEscape(text: string, index: number): boolean;
