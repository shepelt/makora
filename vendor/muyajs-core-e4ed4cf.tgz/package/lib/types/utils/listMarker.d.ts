/** `default` is pandoc's DefaultStyle, written `#.` and numbered like `decimal`. */
export type ListStyle = 'default' | 'decimal' | 'lower-alpha' | 'upper-alpha' | 'lower-roman' | 'upper-roman';
/** `.` is `1.`, `)` is `1)` and `()` is `(1)`. */
export type ListDelimiter = '.' | ')' | '()';
export interface IListMarker {
    value: number;
    style: ListStyle;
    delimiter: ListDelimiter;
}
export interface IListLevel {
    style: ListStyle;
    delimiter: ListDelimiter;
}
/**
 * Read a marker such as `IV.`, `(a)` or `3)`. Without `continueStyle` the
 * text is read as a list's first marker; with it, as a later item of a list
 * in that style (so `v.` continues an `i.` list as five).
 */
export declare function parseListMarker(text: string, continueStyle?: ListStyle): IListMarker | null;
/** `first` uses additive Roman numerals where V/X/L/C/D/M would read as letters. */
export declare function formatListMarker({ value, style, delimiter }: IListMarker, position?: 'first' | 'continuation'): string;
/** Fewest spaces pandoc accepts; `text` disambiguates a following page number. */
export declare function minSpacesAfterMarker({ value, style, delimiter }: IListMarker, text?: string): 1 | 2;
/**
 * Whether `next`'s first written marker continues `list`. Continuation is
 * directional: `i.` can continue an alpha list, but `a.` cannot continue a
 * roman list. `sourceMarker` retains an authored marker when available.
 */
export declare function continuesList(list: IListLevel, next: IListMarker, sourceMarker?: string): boolean;
export declare function toListDelimiter(value: string): ListDelimiter;
/** Ladder level for a zero-based depth; deeper levels reuse the last one. */
export declare function outlineLevel(depth: number): IListLevel;
