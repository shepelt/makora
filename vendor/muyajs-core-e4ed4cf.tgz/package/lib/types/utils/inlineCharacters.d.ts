export declare const UNICODE_PUNCTUATION: RegExp;
export declare const UNICODE_WHITESPACE: RegExp;
export declare const CJK_CHARACTER: RegExp;
