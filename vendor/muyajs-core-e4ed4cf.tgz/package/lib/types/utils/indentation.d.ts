export declare function indentationWidth(prefix: string, startColumn?: number): number;
export declare function indentToTabStop(prefix: string): string;
export declare function indentWithTabs(columns: number, startColumn?: number): string;
export declare function removeIndent(value: string, columns: number, startColumn?: number): string;
