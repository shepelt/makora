import { default as I18n } from '../i18n';
export declare function showCopyFeedback(button: HTMLElement, ok: boolean, label: string, i18n: I18n): void;
