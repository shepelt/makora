export declare const DEFAULT_OPTIONS: {
    footnote: boolean;
    texMathDollars: boolean;
    texMathGfm: boolean;
    texMathSingleBackslash: boolean;
    texMathDoubleBackslash: boolean;
    frontMatter: boolean;
    cjkEmphasis: boolean;
    superSubScript: boolean;
    highlightSyntax: boolean;
    inlineDiff: boolean;
    multilineBlockquote: boolean;
    githubAlerts: boolean;
    fancyLists: boolean;
};
