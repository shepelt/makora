import { MarkedExtension, Tokens } from 'marked';
/** The callback adds trusted ordered-list attributes; nesting whitespace stays shared. */
export default function compactNestedLists(orderedListAttributes?: (token: Tokens.List) => string): MarkedExtension;
