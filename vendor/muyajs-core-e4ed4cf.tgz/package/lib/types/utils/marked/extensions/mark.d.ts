import { MarkedExtension } from 'marked';
export default function markExtension(): MarkedExtension;
