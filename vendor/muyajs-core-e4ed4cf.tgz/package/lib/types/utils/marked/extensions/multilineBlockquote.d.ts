import { MarkedExtension, Tokens } from 'marked';
export interface IMultilineBlockquoteToken {
    type: 'multilineBlockquote';
    raw: string;
    text: string;
    tokens: Tokens.Generic[];
}
export default function multilineBlockquoteExtension(enabled: boolean): MarkedExtension;
