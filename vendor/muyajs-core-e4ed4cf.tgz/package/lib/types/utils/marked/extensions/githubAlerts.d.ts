import { MarkedExtension, Token, Lexer } from 'marked';
import { IGithubAlertState } from '../../../state/types';
export interface IGithubAlertToken {
    type: 'githubAlert';
    raw: string;
    meta: IGithubAlertState['meta'];
    tokens: Token[];
}
/** Only root tokens are eligible; nested quotes keep their Markdown semantics. */
export declare function normalizeGithubAlertTokens(tokens: Token[], lexer: Lexer): void;
export default function githubAlertsExtension(enabled: boolean): MarkedExtension;
