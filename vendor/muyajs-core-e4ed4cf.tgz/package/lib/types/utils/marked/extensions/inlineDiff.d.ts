import { MarkedExtension } from 'marked';
export default function inlineDiffExtension(): MarkedExtension;
