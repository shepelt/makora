import { MarkedExtension } from 'marked';
/** Pandoc fancy lists for marked's HTML renderer: `<ol type="I" class="…">`. */
export default function fancyListsHtmlExtension(): MarkedExtension;
