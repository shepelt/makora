import { Lexer, MarkedExtension } from 'marked';
export declare function endListItemsAtFancyMarkers(lexer: Lexer): void;
export default function fancyListsExtension(): MarkedExtension;
