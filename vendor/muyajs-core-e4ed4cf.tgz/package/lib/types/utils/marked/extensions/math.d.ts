import { Token } from 'marked';
export type TInlineMathType = 'inlineMath' | 'inlineMathGfm' | 'inlineMathSingleBackslash' | 'displayMathSingleBackslash' | 'inlineMathDoubleBackslash' | 'displayMathDoubleBackslash';
export interface IMathToken {
    type: TInlineMathType | 'multiplemath';
    raw: string;
    text: string;
    displayMode: boolean;
    marker?: string;
    closeMarker?: string;
    mathStyle?: '' | 'gfm';
}
interface IOptions {
    throwOnError?: boolean;
    useKatexRender?: boolean;
}
export default function (options?: IOptions): {
    extensions: ({
        name: string;
        level: "inline";
        start(src: string): number | undefined;
        tokenizer(src: string): {
            type: string;
            raw: string;
            text: string;
            marker: string;
            displayMode: boolean;
        } | undefined;
        renderer: (token: IMathToken) => string;
    } | {
        name: string;
        level: "block";
        start(src: string): number;
        tokenizer(src: string): {
            type: string;
            raw: string;
            text: string;
            displayMode: boolean;
            mathStyle: string;
        } | undefined;
        renderer: (token: IMathToken) => string;
    })[];
    walkTokens: typeof markDisplayMath;
};
export declare function gfmMathExtension(options?: IOptions): {
    extensions: {
        name: string;
        level: "inline";
        start(src: string): number | undefined;
        tokenizer(src: string): {
            type: string;
            raw: string;
            text: string;
            marker: string;
            closeMarker: string;
            displayMode: boolean;
        } | undefined;
        renderer: (token: IMathToken) => string;
    }[];
};
export declare function singleBackslashMathExtension(options?: IOptions): {
    extensions: {
        name: TInlineMathType;
        level: "inline";
        start(src: string): number | undefined;
        tokenizer(src: string): {
            type: TInlineMathType;
            raw: string;
            text: string;
            marker: string;
            closeMarker: string;
            displayMode: boolean;
        } | undefined;
        renderer: (token: IMathToken) => string;
    }[];
    walkTokens: typeof markDisplayMath;
};
export declare function doubleBackslashMathExtension(options?: IOptions): {
    extensions: {
        name: TInlineMathType;
        level: "inline";
        start(src: string): number | undefined;
        tokenizer(src: string): {
            type: TInlineMathType;
            raw: string;
            text: string;
            marker: string;
            closeMarker: string;
            displayMode: boolean;
        } | undefined;
        renderer: (token: IMathToken) => string;
    }[];
    walkTokens: typeof markDisplayMath;
};
declare function markDisplayMath(token: Token): void;
export {};
