import { MarkedExtension } from 'marked';
export default function inlineDelimitersExtension(cjkEmphasis?: boolean): MarkedExtension;
