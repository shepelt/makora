export interface IHtmlBlockBoundary {
    interruptsParagraph: boolean;
    endsWithoutBlankLine: boolean;
}
/** Derive HTML boundaries from the same grammar as import, including edited HTML. */
export declare function getHtmlBlockBoundary(html: string): IHtmlBlockBoundary;
