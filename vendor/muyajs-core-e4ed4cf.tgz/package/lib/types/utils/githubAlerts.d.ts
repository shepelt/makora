import { default as Parent } from '../block/base/parent';
import { IGithubAlertState } from '../state/types';
export declare const GITHUB_ALERT_TYPES: readonly ["NOTE", "TIP", "IMPORTANT", "WARNING", "CAUTION"];
export type GithubAlertType = typeof GITHUB_ALERT_TYPES[number];
export declare function githubAlertType(value: string): GithubAlertType | null;
export declare function matchGithubAlertMarker(text: string): GithubAlertType | null;
export declare function githubAlertTitle(type: GithubAlertType): string;
export declare function githubAlertIcon(type: GithubAlertType): string;
export declare function githubAlertMenuIcon(type: GithubAlertType): string;
export declare function githubAlertMarker(meta: IGithubAlertState['meta']): string;
export declare function githubAlertBlockType(block: Parent): GithubAlertType | null;
/** Restore portable Markdown semantics before Turndown discards generated titles. */
export declare function restoreGithubAlertQuotes(html: string): string;
