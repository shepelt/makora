export type ColorFormatType = 'color' | 'bg_color';
export interface IColorStyle {
    color: string | null;
    backgroundColor: string | null;
}
export declare const COLOR_SPAN_CLOSE_TAG = "</span>";
export declare function colorPropertyOf(type: ColorFormatType): string;
export declare function parseColorStyle(style: string | null | undefined): IColorStyle | null;
export declare function isColorStyleEmpty(style: IColorStyle): boolean;
export declare function serializeColorStyle(style: IColorStyle): string;
export declare function colorSpanOpenTag(style: IColorStyle): string;
