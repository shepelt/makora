import { IMuyaOptions } from '../types';
import { PasteType } from '../clipboard/types';
interface INormalizePastedHTMLOptions {
    preserveBareUrlLinks?: boolean;
    fetchLinkHtml?: IMuyaOptions['fetchLinkHtml'];
    resolveLinkTitles?: boolean;
}
export declare const isOnline: () => boolean;
export declare function isHttpUrl(text: string): boolean;
export declare function getPageTitle(url: string, fetchLinkHtml?: IMuyaOptions['fetchLinkHtml']): Promise<string>;
export declare function normalizePastedHTML(html: string, options?: INormalizePastedHTMLOptions): Promise<string>;
export declare function isStandaloneTableHtml(text: string): boolean;
export declare function resolveClipboardImagePath(hook: (() => Promise<string>) | undefined): Promise<string>;
export declare function getClipboardImageFile(clipboardData: DataTransfer | null): File | null;
export declare function readFileAsDataURL(file: File): Promise<string>;
export declare function getCopyTextType(html: string, text: string, pasteType: PasteType): "text" | "code" | "html";
export {};
