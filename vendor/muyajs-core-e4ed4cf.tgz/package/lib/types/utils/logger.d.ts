export type TLogLevel = 'error' | 'warn' | 'log' | 'info';
export type TLogSink = (level: TLogLevel, ...args: unknown[]) => void;
type Ilogger = Record<TLogLevel, (...args: unknown[]) => void>;
declare function namespace(ns: string): Ilogger;
declare namespace namespace {
    var level: (newLevel: TLogLevel) => void;
    var setSink: (newSink?: TLogSink) => void;
}
export default namespace;
