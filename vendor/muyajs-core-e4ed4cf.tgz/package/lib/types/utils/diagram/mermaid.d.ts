interface IMermaidRenderOptions {
    target: HTMLElement;
    theme: string;
    code?: string;
}
export declare function renderMermaid({ target, theme, code }: IMermaidRenderOptions): Promise<void>;
export {};
