export default class Diagram {
    encodedInput: string;
    plantumlServer: string;
    static parse(input: string, plantumlServer?: string): Diagram;
    private _encode;
    insertImgElement(container: string | HTMLElement): void;
}
