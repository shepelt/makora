import { IDiagramMeta, IDiagramState } from '../../state/types';
/**
 * The diagram type a fence language renders as, or null for a code language.
 * @param lang the first word of the fence info string
 */
export declare function diagramTypeOfLang(lang: string): IDiagramMeta['type'] | null;
export declare function createDiagramState(type: IDiagramMeta['type'], text?: string): IDiagramState;
