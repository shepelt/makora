declare function loadRenderer(name: string): Promise<any>;
export default loadRenderer;
