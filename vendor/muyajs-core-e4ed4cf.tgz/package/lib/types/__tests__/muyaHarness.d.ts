import { Muya } from '../muya';
/**
 * Register the per-test MUYA_VERSION stub and automatic teardown of any Muya
 * booted via `bootMuya`. Call once at the top of a `describe` file.
 */
export declare function useMuyaHarness(): void;
/** Boot a Muya editor on a fresh host from the given markdown. Auto-torn-down. */
export declare function bootMuya(markdown: string): Muya;
