import { Path } from 'ot-json1';
export declare function stateAtPath(root: unknown, path: Path): unknown;
