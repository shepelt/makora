import { JSONOp } from 'ot-json1';
import { TSelectionState } from '../selection/types';
import { ChangeSource } from '../types';
import { TState } from './types';
export interface IJSONChangePayload {
    op: JSONOp;
    source: ChangeSource;
    prevDoc: TState[];
    doc: TState[];
}
export declare function createChangePayload(op: JSONOp, source: ChangeSource, before: readonly TState[], after: readonly TState[], recordHistory?: boolean, recordSelection?: TSelectionState | null): IJSONChangePayload;
export declare function getRecordSelection(payload: IJSONChangePayload): TSelectionState | null;
export declare function isHistorySuppressed(payload: IJSONChangePayload): boolean;
/**
 * Read-only input for History; also accepts manually emitted events.
 * @internal
 */
export declare function getPreviousDoc(payload: Pick<IJSONChangePayload, 'prevDoc'>): readonly TState[];
