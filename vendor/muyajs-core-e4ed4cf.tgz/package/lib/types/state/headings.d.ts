/** The inline Markdown body, without ATX markers or their surrounding whitespace. */
export declare function atxHeadingBody(text: string): string;
export declare function atxHeadingPrefixLength(text: string): number;
export declare function atxHeadingBodyRange(text: string): {
    start: number;
    end: number;
};
export declare function splitAtxHeading(text: string, start: number, end: number): {
    head: string;
    tail: string;
    suffix: string;
};
export declare function changeAtxHeadingLevel(text: string, level: number): string;
