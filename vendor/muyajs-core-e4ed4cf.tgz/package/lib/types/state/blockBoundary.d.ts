import { TState } from './types';
export type TBlockSeparation = 'adjacent' | 'blank-line' | 'rewrite-required';
export interface IBlockBoundaryContext {
    tightListItem: boolean;
}
/**
 * Choose a separator without changing block meaning. A blank line can change
 * list tightness, and cannot separate two indented code blocks at all.
 */
export declare class BlockBoundaryResolver {
    private _htmlBoundaries;
    reset(): void;
    resolve(previous: TState, next: TState, context: IBlockBoundaryContext): TBlockSeparation;
    private _interruptsParagraph;
    private _htmlBoundary;
}
