import { Muya } from '../muya';
export interface IExportHeading {
    lvl: number;
    content: string;
    contentHtml: string;
    slug: string;
}
export interface IHtmlExport {
    html: string;
    /** Headings in document order, with the IDs assigned in `html`. */
    headings: IExportHeading[];
}
export interface IHtmlExportOptions {
    title?: string;
    extraCSS?: string;
    inlineStyles?: boolean;
    dir?: string;
}
export declare class MarkdownToHtml {
    markdown: string;
    private _muya?;
    private _exportContainer;
    constructor(markdown: string, _muya?: Muya | undefined);
    private _renderMermaid;
    private _renderDiagram;
    private _injectHeadingIds;
    renderHtml(): Promise<string>;
    renderHtmlWithHeadings(): Promise<IHtmlExport>;
    /**
     * Get HTML with style.
     *
     * @param options Document options.
     * @param options.title Document `<title>`.
     * @param options.extraCSS Extra CSS appended after the base stylesheets.
     * @param options.inlineStyles Inline the core stylesheets so the output is
     * self-contained and renders offline (default `true`); pass `false` to fall
     * back to CDN `<link>` tags.
     * @param options.dir Text direction set on the root `<html>` (`rtl` / `auto`);
     * `ltr` is the HTML default and stays implicit.
     */
    generate(options?: IHtmlExportOptions): Promise<string>;
    /** Return the document and heading metadata from the same render pass. */
    generateWithHeadings(options?: IHtmlExportOptions): Promise<IHtmlExport>;
}
