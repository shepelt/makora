import { Doc, JSONOp, JSONOpList } from 'ot-json1';
import { Muya } from '../muya';
import { TState } from './types';
export declare function asDoc(state: readonly TState[] | TState): Doc;
export declare function asState(doc: unknown): TState[];
declare class JSONState {
    private _muya;
    static invert(op: JSONOpList): JSONOp;
    static compose(op1: JSONOpList, op2: JSONOpList): JSONOp;
    static transform(op: JSONOpList, otherOp: JSONOpList, type: 'left' | 'right'): JSONOpList | null | undefined;
    private _state;
    private _revision;
    constructor(_muya: Muya, stateOrMarkdown: TState[] | string);
    get revision(): number;
    /** Read-only candidate: owns inserted values, shares untouched subtrees. */
    preview(op: JSONOp): readonly TState[];
    /** Apply a complete operation exactly as supplied, without editing rules or events. */
    apply(op: JSONOp): void;
    setContent(content: TState[] | string): void;
    private _setState;
    private _setMarkdown;
    markdownToState(markdown: string): TState[];
    /**
     * Build an invertible replacement operation; null means no change.
     * Uses top-level replacements rather than moves; callers must rebuild the
     * block tree instead of applying it through the incremental DOM walker.
     */
    buildReplaceOp(content: TState[] | string): JSONOp;
    /**
     * Complete logical state. Consumers must never mutate this tree.
     * @internal
     */
    get rawState(): readonly TState[];
    getState(): TState[];
    getMarkdown(): string;
    getTOC(): import('./getTOC').ITocItem[];
    getMarkdownFromState(state: TState[]): string;
}
export default JSONState;
