import { TState } from './types';
interface IMarkdownToStateOptions {
    footnote: boolean;
    texMathDollars: boolean;
    texMathGfm: boolean;
    texMathSingleBackslash: boolean;
    texMathDoubleBackslash: boolean;
    trimUnnecessaryCodeBlockEmptyLines: boolean;
    frontMatter: boolean;
    multilineBlockquote?: boolean;
    githubAlerts?: boolean;
    fancyLists?: boolean;
}
export declare class MarkdownToState {
    private _options;
    constructor(_options?: Partial<IMarkdownToStateOptions>);
    generate(markdown: string): TState[];
    private _convertMarkdownToState;
    private _handleContainerToken;
    private _buildListState;
    private _handleLeafToken;
    private _buildHeadingState;
    private _buildTableState;
    private _buildCodeState;
}
export {};
