import { IEvent, IListeners, Listener, TEventArgs, TEventListener } from './types';
declare class EventCenter {
    events: IEvent[];
    listeners: IListeners;
    private get _eventId();
    /**
     * [attachDOMEvent] bind event listener to target, and return a unique ID,
     * this ID
     */
    attachDOMEvent(target: HTMLElement | Document, event: string, listener: EventListener, capture?: boolean | AddEventListenerOptions): string;
    /**
     * [detachDOMEvent removeEventListener]
     * @param  {[type]} eventId [unique eventId]
     */
    detachDOMEvent(eventId: string): false | undefined;
    /**
     * [detachAllDomEvents remove all the DOM events handler]
     */
    detachAllDomEvents(): void;
    /**
     * inner method for on and once
     */
    subscribe<K extends string>(event: K, listener: TEventListener<K>, once?: boolean): void;
    /**
     * [on] on custom event
     */
    on<K extends string>(event: K, listener: TEventListener<K>): void;
    /**
     * [off] off custom event
     */
    off(event: string, listener: Listener): void;
    /**
     * [once] subscribe event and listen once
     */
    once<K extends string>(event: K, listener: TEventListener<K>): void;
    /**
     * emit custom event
     */
    emit<K extends string>(event: K, ...data: TEventArgs<K>): void;
    /**
     * Remove all pub/sub subscriptions. Called from muya.destroy() to
     * release listener closures so the host page can GC the Muya instance.
     */
    unsubscribeAll(): void;
    private _checkHasBind;
}
export default EventCenter;
