import { default as Content } from './base/content';
import { default as Parent } from './base/parent';
export declare function moveListItems(items: Parent[], direction: 'indent' | 'outdent'): Map<Content, Content> | null;
