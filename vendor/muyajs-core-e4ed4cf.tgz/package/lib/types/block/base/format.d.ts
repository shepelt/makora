import { TextToken, Token } from '../../inline/model/types';
import { IContentCursor, IRenderCursor } from '../../selection/types';
import { ColorFormatType } from '../../utils/colorSpan';
import { IImageInfo } from '../../utils/image';
import { default as Content } from '../../block/base/content';
declare class Format extends Content {
    static blockName: string;
    protected get autoPairType(): string;
    private _checkCursorInTokenType;
    private _checkNotSameToken;
    checkNeedRender(cursor?: IRenderCursor): boolean;
    blurHandler(): void;
    /**
     * Update emoji text if cursor is in emoji syntax.
     * @param {string} text emoji text
     */
    setEmoji(text: string): void;
    replaceImage({ token }: IImageInfo, { alt, src, title }: {
        alt?: string | undefined;
        src?: string | undefined;
        title?: string | undefined;
    }): void;
    updateImage({ token }: IImageInfo, attrName: string, attrValue: string): void;
    unlink({ range, text }: {
        range: {
            start: number;
            end: number;
        } | null;
        text: string;
    }): void;
    deleteImage({ token }: IImageInfo): void;
    clickHandler(event: Event): void;
    keyupHandler(): void;
    inputHandler(event: Event): void;
    checkInlineUpdate(): void;
    private _convertIfNeeded;
    private _convertToThematicBreak;
    private _convertToList;
    private _fancyListPrefix;
    private _convertToFancyList;
    private _replaceParagraphWithList;
    private _convertToTaskList;
    private _convertToAtxHeading;
    private _convertToSetextHeading;
    private _convertToBlockQuote;
    private _convertToIndentedCodeBlock;
    protected convertToParagraph(force?: boolean): void;
    backspaceHandler(event: Event): void;
    private _scanBackspaceTokens;
    private _caretOffsetOnInlineImage;
    private _isTrailingInlineImage;
    private _selectInlineImage;
    deleteHandler(event: KeyboardEvent): void;
    protected shiftEnterHandler(event: Event): void;
    protected dropSoftBreakBeforeCursor(): boolean;
    enterHandler(event: KeyboardEvent): void;
    protected splitToParagraph(event: KeyboardEvent, head: string, tail: string): void;
    getFormatsInRange(cursor?: IContentCursor | null): {
        formats: (import('../../inline/model/types').BeginRuleToken | import('../../inline/model/types').ReferenceDefinitionToken | TextToken | import('../../inline/model/types').BacklashToken | import('../../inline/model/types').StrongEmToken | import('../../inline/model/types').InlineCodeToken | import('../../inline/model/types').EmojiToken | import('../../inline/model/types').InlineMathToken | import('../../inline/model/types').DelToken | import('../../inline/model/types').MarkToken | import('../../inline/model/types').InlineDiffToken | import('../../inline/model/types').SuperSubScriptToken | import('../../inline/model/types').FootnoteIdentifierToken | import('../../inline/model/types').ImageToken | import('../../inline/model/types').LinkToken | import('../../inline/model/types').ReferenceLinkToken | import('../../inline/model/types').ReferenceImageToken | import('../../inline/model/types').HTMLEscapeToken | import('../../inline/model/types').AutoLinkExtensionToken | import('../../inline/model/types').AutoLinkToken | import('../../inline/model/types').HTMLTagToken | import('../../inline/model/types').SoftLineBreakToken | import('../../inline/model/types').HardLineBreakToken | import('../../inline/model/types').TailHeaderToken)[];
        tokens: Token[];
        neighbors: (import('../../inline/model/types').BeginRuleToken | import('../../inline/model/types').ReferenceDefinitionToken | TextToken | import('../../inline/model/types').BacklashToken | import('../../inline/model/types').StrongEmToken | import('../../inline/model/types').InlineCodeToken | import('../../inline/model/types').EmojiToken | import('../../inline/model/types').InlineMathToken | import('../../inline/model/types').DelToken | import('../../inline/model/types').MarkToken | import('../../inline/model/types').InlineDiffToken | import('../../inline/model/types').SuperSubScriptToken | import('../../inline/model/types').FootnoteIdentifierToken | import('../../inline/model/types').ImageToken | import('../../inline/model/types').LinkToken | import('../../inline/model/types').ReferenceLinkToken | import('../../inline/model/types').ReferenceImageToken | import('../../inline/model/types').HTMLEscapeToken | import('../../inline/model/types').AutoLinkExtensionToken | import('../../inline/model/types').AutoLinkToken | import('../../inline/model/types').HTMLTagToken | import('../../inline/model/types').SoftLineBreakToken | import('../../inline/model/types').HardLineBreakToken | import('../../inline/model/types').TailHeaderToken)[];
    };
    format(type: string): void;
    /**
     * Unlike `format()`, this replaces rather than only toggles: picking the
     * applied colour clears it, a different colour replaces it, and the other
     * declaration on a shared span is preserved (both stay in one span).
     */
    formatColor(type: ColorFormatType, value: string | null): void;
    private _addFormat;
    private _handleClickInlineRuleRender;
    private _emitFootnoteToolEvent;
}
export default Format;
