import { IHighlight } from '../../inline/model/types';
import { Muya } from '../../muya';
import { IContentCursor, INodeOffset, IRenderCursor } from '../../selection/types';
import { Nullable, ChangeSource } from '../../types';
import { TBlockPath } from '../types';
import { default as Parent } from './parent';
import { default as TreeNode } from '../../block/base/treeNode';
import { default as Selection } from '../../selection';
export declare function isDocumentBoundaryArrow(event: KeyboardEvent, osx?: boolean): boolean;
declare class Content extends TreeNode {
    private _text;
    protected isComposed: boolean;
    private _compositionAnchor;
    private _compositionLineEnd;
    static blockName: string;
    protected get hasSelection(): boolean;
    protected get selection(): Selection;
    protected get inlineEngine(): import('../../inline').default;
    protected get autoPairType(): string;
    get path(): TBlockPath;
    get text(): string;
    set text(text: string);
    protected get isCollapsed(): boolean | undefined;
    get isContainerBlock(): boolean;
    constructor(muya: Muya, text: string);
    getAnchor(): Nullable<Parent>;
    clickHandler(event: Event): void;
    tabHandler(_event: Event): void;
    keyupHandler(_event: Event): void;
    inputHandler(_event: Event): void;
    backspaceHandler(_event: Event): void;
    /** Return true to consume a block shortcut before the default key routing. */
    beforeKeydown(_event: KeyboardEvent): boolean;
    enterHandler(_event: Event): void;
    deleteHandler(event: Event): void;
    private _revealArrowSelectionTarget;
    arrowHandler(event: Event): void;
    private _upArrowOffset;
    private _moveDownOntoTrailingBlankLine;
    /**
     * Whether the key is left to the browser's own move. Its y-offset test cannot
     * measure a caret on an empty line (no rect), so a line break on the caret's
     * side decides that case instead.
     */
    private _deferArrowToBrowser;
    /** The cross-block direction the key moves in, or null for the keys the browser keeps. */
    private _arrowDirection;
    private _lineBreakOnCaretSide;
    private _downArrowOffset;
    private _nearestOffsetAtColumn;
    createDomNode(): void;
    getCursor(): IContentCursor | null;
    setCursor(begin: number, end: number, needUpdate?: boolean): void;
    update(_cursor?: IRenderCursor, _highlights?: IHighlight[]): void;
    composeHandler(event: Event): void;
    private _seedCompositionAnchor;
    /**
     * Strip the seeded anchor, keeping the text the IME committed into it and
     * the caret where the user sees it, so the input handler that runs next
     * reads an anchor-free block.
     */
    private _consumeCompositionAnchor;
    autoPair(event: Event, text: string, start: INodeOffset, end: INodeOffset, isInInlineMath?: boolean, isInInlineCode?: boolean, type?: string): {
        text: string;
        needRender: boolean;
    };
    protected insertTab(unindent?: boolean): void;
    replaceCurrentWordInlineUnsafe(word: string, replacement: string): boolean;
    keydownHandler: (event: Event) => void;
    private _wrapSelectionWithAutoPair;
    blurHandler(): void;
    focusHandler(): void;
    getAncestors(): Parent[];
    remove(source?: ChangeSource): this;
}
export default Content;
