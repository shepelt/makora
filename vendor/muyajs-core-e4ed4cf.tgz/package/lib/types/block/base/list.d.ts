import { default as Parent } from './parent';
export default abstract class ListBlock extends Parent {
    abstract meta: {
        loose: boolean;
    };
    setLoose(loose: boolean): void;
}
