import { TState } from '../../state/types';
import { Nullable, ChangeSource } from '../../types';
import { TBlockPath } from '../types';
import { LinkedList } from '../../block/base/linkedList/linkedList';
import { default as TreeNode } from '../../block/base/treeNode';
declare class Parent extends TreeNode {
    attachments: LinkedList<TreeNode>;
    children: LinkedList<TreeNode>;
    prev: Nullable<Parent>;
    next: Nullable<Parent>;
    private _active;
    get active(): boolean;
    set active(value: boolean);
    get firstChild(): Nullable<TreeNode>;
    get lastChild(): Nullable<TreeNode>;
    protected get isContainerBlock(): boolean;
    get path(): TBlockPath;
    private _getJsonPath;
    getState(): TState;
    clone(): any;
    length(): number;
    offset(node: TreeNode): number;
    find(offset: number): TreeNode | null;
    append(...childrenAndSource: [...Parent[], ChangeSource]): void;
    append(...children: Parent[]): void;
    /**
     * This method will only be used when initialization.
     * @param  {...any} nodes attachment blocks
     */
    protected appendAttachment(...nodes: TreeNode[]): void;
    forEachAt(index: number, length: number | undefined, callback: (cur: TreeNode, i: number) => void): void;
    forEach(callback: (cur: TreeNode, i: number) => void): void;
    map<M>(callback: (cur: TreeNode, i: number) => M): M[];
    reduce<M>(callback: (memo: M, cur: TreeNode, i: number) => M, initialValue: M): M;
    replaceWith(block: Parent, source?: ChangeSource): Parent | undefined;
    insertBefore(newNode: Parent, refNode?: Nullable<Parent>, source?: ChangeSource): Parent | undefined;
    insertAfter(newNode: Parent, refNode?: Nullable<Parent>, source?: ChangeSource): Parent;
    remove(source?: ChangeSource): this | undefined;
    protected empty(): void;
    removeChild(node: TreeNode, source?: ChangeSource): TreeNode;
    firstContentInDescendant(): import('./content').default | null;
    lastContentInDescendant(): import('./content').default | null;
    breadthFirstTraverse(this: Parent, callback: (node: TreeNode) => void): void;
    depthFirstTraverse(this: Parent, callback: (node: TreeNode) => void): void;
}
export default Parent;
