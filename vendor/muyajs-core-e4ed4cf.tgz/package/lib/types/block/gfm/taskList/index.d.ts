import { Muya } from '../../../muya';
import { ITaskListMeta, ITaskListState } from '../../../state/types';
import { default as ListBlock } from '../../base/list';
declare class TaskList extends ListBlock {
    meta: ITaskListMeta;
    static blockName: string;
    static create(muya: Muya, state: ITaskListState): TaskList;
    get path(): (string | number)[];
    constructor(muya: Muya, { meta }: ITaskListState);
    orderIfNecessary(): void;
    getState(): ITaskListState;
}
export default TaskList;
