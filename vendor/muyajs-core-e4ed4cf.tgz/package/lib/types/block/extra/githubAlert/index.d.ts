import { Muya } from '../../../muya';
import { IGithubAlertState } from '../../../state/types';
import { default as QuoteContainer } from '../../base/quoteContainer';
export default class GithubAlert extends QuoteContainer {
    static blockName: string;
    meta: IGithubAlertState['meta'];
    static create(muya: Muya, state: IGithubAlertState): GithubAlert;
    constructor(muya: Muya, state: IGithubAlertState);
    getState(): IGithubAlertState;
}
