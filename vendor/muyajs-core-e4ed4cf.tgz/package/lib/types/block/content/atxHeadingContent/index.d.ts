import { Muya } from '../../../muya';
import { IRenderCursor } from '../../../selection/types';
import { default as AtxHeading } from '../../commonMark/atxHeading';
import { default as Format } from '../../base/format';
declare class AtxHeadingContent extends Format {
    parent: AtxHeading | null;
    static blockName: string;
    static create(muya: Muya, text: string): AtxHeadingContent;
    constructor(muya: Muya, text: string);
    getAnchor(): AtxHeading | null;
    beforeKeydown(event: KeyboardEvent): boolean;
    update(cursor?: IRenderCursor, highlights?: never[]): void;
    enterHandler(event: Event): void;
    deleteHandler(event: KeyboardEvent): void;
    backspaceHandler(event: Event): void;
}
export default AtxHeadingContent;
