import { IHighlight } from '../../../inline/model/types';
export declare function escapeLangInputInnerHtml(text: string, highlights?: IHighlight[]): string;
