import { Muya } from '../muya';
import { IAtxHeadingState, IFrontmatterMeta } from '../state/types';
import { default as Parent } from './base/parent';
export declare function frontmatterMeta(frontmatterType: string): IFrontmatterMeta;
export declare function insertFrontMatterAtStart(muya: Muya): boolean;
export declare function showTablePicker(muya: Muya, block: Parent): void;
export declare function canInsertLabel(label: string, muya: Muya): boolean;
export declare function buildReplacementBlock(label: string, muya: Muya, text: string, source?: IAtxHeadingState): any;
export declare function replaceBlockByLabel({ block, muya, label, text }: {
    block: Parent;
    muya: Muya;
    label: string;
    text?: string;
}): void;
export declare function insertBlockBelowByLabel({ block, muya, label }: {
    block: Parent;
    muya: Muya;
    label: string;
}): void;
export declare function canTurnInto(block: Parent, label: string): boolean;
