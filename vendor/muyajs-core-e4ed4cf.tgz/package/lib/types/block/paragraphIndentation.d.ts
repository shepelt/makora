import { IResolvedTextSelection } from '../selection/types';
import { default as Content } from './base/content';
export declare function convertIndentedParagraphs(contents: Content[], selection: IResolvedTextSelection): void;
