import { Muya } from '../../../muya';
import { IAtxHeadingState } from '../../../state/types';
import { TBlockPath } from '../../types';
import { default as Parent } from '../../base/parent';
declare class AtxHeading extends Parent {
    meta: IAtxHeadingState['meta'];
    private _folded;
    private _foldToggle;
    static blockName: string;
    static create(muya: Muya, state: IAtxHeadingState): AtxHeading;
    get path(): TBlockPath;
    constructor(muya: Muya, { meta }: IAtxHeadingState);
    get folded(): boolean;
    /** Fold state is transient; placing a caret in hidden content reveals its section. */
    toggleFold(folded?: boolean): void;
    getState(): IAtxHeadingState;
}
export default AtxHeading;
