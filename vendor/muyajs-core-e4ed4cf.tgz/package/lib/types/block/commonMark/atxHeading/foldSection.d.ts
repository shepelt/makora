import { Nullable } from '../../../types';
export interface IFoldSibling {
    blockName: string;
    /** Heading level 1..6; undefined for non-heading blocks. */
    level?: number;
    folded?: boolean;
    /** Inclusive sibling index captured when folded; omitted for an unbounded section. */
    foldEnd?: number;
}
export interface IHeadingNode {
    blockName: string;
    meta?: {
        level?: number;
    };
    folded?: boolean;
    toggleFold?: (folded?: boolean) => void;
}
export interface IFoldableHeading extends IHeadingNode {
    blockName: 'atx-heading';
    meta: {
        level: number;
    };
    folded: boolean;
    toggleFold: (folded?: boolean) => void;
}
/** ATX and Setext headings share section boundaries regardless of fold support. */
export declare function headingLevel(node: Nullable<IHeadingNode>): number | undefined;
export declare function isFoldableHeading(node: Nullable<IHeadingNode>): node is IFoldableHeading;
/** A folded heading hides following siblings until the next equal or higher heading. */
export declare function hiddenByFoldedSections(sectionBlocks: IFoldSibling[]): boolean[];
export interface IFoldKeyChord {
    key: string;
    code: string;
    shiftKey: boolean;
    metaKey: boolean;
    ctrlKey: boolean;
    altKey: boolean;
}
/** Physical key codes also match layouts where Shift+[ produces another character. */
export declare function isFoldShortcut(event: IFoldKeyChord): boolean;
