import { Muya } from '../../../muya';
import { IBlockQuoteState } from '../../../state/types';
import { default as QuoteContainer } from '../../base/quoteContainer';
declare class BlockQuote extends QuoteContainer {
    static blockName: string;
    private _meta?;
    get meta(): {
        style?: "fenced";
    } | undefined;
    static create(muya: Muya, state: IBlockQuoteState): BlockQuote;
    constructor(muya: Muya);
    getState(): IBlockQuoteState;
}
export default BlockQuote;
