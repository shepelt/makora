import { Muya } from '../../../muya';
import { default as TreeNode } from '../../base/treeNode';
declare class HeadingCopyLink extends TreeNode {
    static blockName: string;
    static create(muya: Muya, _state?: unknown): HeadingCopyLink;
    get isContainerBlock(): boolean;
    constructor(muya: Muya);
    private _listen;
    private _activate;
    getState(): void;
}
export default HeadingCopyLink;
