import { Muya } from '../../../muya';
import { default as TreeNode } from '../../base/treeNode';
declare class HeadingFoldToggle extends TreeNode {
    static blockName: string;
    static create(muya: Muya, _state?: unknown): HeadingFoldToggle;
    get isContainerBlock(): boolean;
    constructor(muya: Muya);
    private _listen;
    private _activate;
    reflectFolded(folded: boolean): void;
    private _updateLabel;
    getState(): void;
}
export default HeadingFoldToggle;
