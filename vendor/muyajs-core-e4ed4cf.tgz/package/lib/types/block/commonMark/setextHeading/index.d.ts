import { Muya } from '../../../muya';
import { ISetextHeadingState } from '../../../state/types';
import { default as Parent } from '../../base/parent';
declare class SetextHeading extends Parent {
    meta: ISetextHeadingState['meta'];
    syntax: ISetextHeadingState['syntax'];
    static blockName: string;
    static create(muya: Muya, state: ISetextHeadingState): SetextHeading;
    get path(): (string | number)[];
    constructor(muya: Muya, { meta, syntax }: ISetextHeadingState);
    setSyntax(syntax: ISetextHeadingState['syntax']): void;
    getState(): ISetextHeadingState;
}
export default SetextHeading;
