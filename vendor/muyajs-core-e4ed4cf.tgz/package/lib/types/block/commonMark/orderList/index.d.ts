import { Muya } from '../../../muya';
import { IOrderListState } from '../../../state/types';
import { default as Parent } from '../../base/parent';
import { LinkedList } from '../../base/linkedList/linkedList';
import { default as ListBlock } from '../../base/list';
declare class OrderList extends ListBlock {
    children: LinkedList<Parent>;
    meta: IOrderListState['meta'];
    static blockName: string;
    static create(muya: Muya, state: IOrderListState): OrderList;
    get path(): (string | number)[];
    constructor(muya: Muya, { meta }: IOrderListState);
    getState(): IOrderListState;
}
export default OrderList;
