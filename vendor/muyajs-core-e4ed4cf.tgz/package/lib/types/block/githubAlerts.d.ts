import { default as Parent } from './base/parent';
export declare function canConvertGithubAlert(block: Parent, label: string): boolean;
export declare function convertGithubAlert(block: Parent, label: string, text?: string): boolean;
