import { default as Parent } from './base/parent';
import { default as TreeNode } from './base/treeNode';
import { ScrollPage } from './scrollPage';
import { TBlockPath } from './types';
/** Transient view state tied to an unchanged document structure, independent of markdown and undo. */
export interface IHeadingFoldState {
    path: TBlockPath;
    /** Inclusive sibling index of the section's captured tail. */
    end: number;
}
export declare function getHeadingFoldState(root: Parent): IHeadingFoldState[];
export declare function setHeadingFoldState(root: ScrollPage, state: IHeadingFoldState[]): void;
/** Recompute direct-child visibility; nested containers own their own folds. */
export declare function refreshFoldVisibility(parent: Parent, foldChanged?: boolean): void;
/** Includes enclosing containers and the captured boundaries of folded sections. */
export declare function isHiddenByFold(block: TreeNode): boolean;
/** Reveal a target without unfolding unrelated sections or the target heading itself. */
export declare function revealBlock(block: TreeNode): void;
/** Find-in-document exposes all content, including sections without a match. */
export declare function unfoldAllSections(root: Parent): void;
