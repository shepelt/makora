import { Muya } from '../muya';
import { IMatch, IReplaceOption, ISearchOption } from './types';
export declare class Search {
    private _muya;
    private _query;
    private _options;
    private _startPosition;
    private _updating;
    private _visible;
    private _dirty;
    private _renderedMatches;
    matches: IMatch[];
    index: number;
    get value(): string;
    get isUpdatingSelection(): boolean;
    private get _scrollPage();
    constructor(_muya: Muya);
    private _comparePosition;
    private _isSelectedMatch;
    private _restoreExternalFocus;
    private _selectMatch;
    private _findMatchIndex;
    /** Hiding highlights keeps the query available for keyboard navigation. */
    setVisible(visible: boolean): this;
    reset(): void;
    private _updateMatches;
    private _renderHighlights;
    private _innerReplace;
    replace(replaceValue: string, opt?: IReplaceOption): this;
    private _replaceFromSelection;
    find(action: 'previous' | 'next'): this;
    search(query: string, opts?: ISearchOption): this;
    private _search;
    private _searchIndex;
    /** Refresh visible results; defer hidden results until reopening or navigation. */
    refresh(): this;
}
