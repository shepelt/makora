export declare function withMarkdownSource(html: string): string;
export declare function hasMarkdownSource(html: string): boolean;
