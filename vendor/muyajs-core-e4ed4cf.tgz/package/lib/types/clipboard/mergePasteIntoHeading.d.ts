import { default as Content } from '../block/base/content';
import { default as Parent } from '../block/base/parent';
import { TState } from '../state/types';
import { Nullable } from '../types';
interface IPasteCursor {
    startOffset: number;
    endOffset: number;
}
export declare function mergePasteIntoHeading(anchorBlock: Content, wrapperBlock: Nullable<Pick<Parent, 'blockName'>>, states: TState[], cursor: IPasteCursor): TState[];
export {};
