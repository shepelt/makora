import { default as Content } from '../block/base/content';
import { default as Format } from '../block/base/format';
import { Nullable } from '../types';
import { default as Clipboard } from './index';
export declare function insertImageSrc(clipboard: Clipboard, anchorBlock: Content, src: string): Promise<void>;
export declare function resolveImageSrc(clipboard: Clipboard, imageFile: Nullable<File>): Promise<string | null>;
export declare function pasteImageSrc(clipboard: Clipboard, src: string): Promise<void>;
export declare function replaceImageAt(clipboard: Clipboard, block: Format, range: {
    start: number;
    end: number;
}, src: string): Promise<void>;
