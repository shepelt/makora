import { default as Clipboard } from './index';
export interface IClipboardImage {
    version: 1;
    markdown: string;
    src: string;
    documentId: string;
}
export interface IClipboardImageCopy {
    src: string;
    text: string;
    html: string;
    marker: string;
}
export declare function imageClipboardData(clipboard: Clipboard): IClipboardImageCopy | null;
export declare function readClipboardImage(html: string, text: string): IClipboardImage | null;
export declare function pasteClipboardImage(clipboard: Clipboard, image: IClipboardImage): Promise<void>;
