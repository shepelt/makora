import { default as Clipboard } from './index';
export declare function insertTextAtCursor(clipboard: Clipboard, text: string): void;
export declare function cutSelection(clipboard: Clipboard): void;
export declare function deleteTableSelection(clipboard: Clipboard): void;
