import { default as Parent } from '../block/base/parent';
import { default as Clipboard } from './index';
import { CopyType } from './types';
export interface IClipboardPayload {
    html: string;
    text: string;
}
export declare function getClipboardData(clipboard: Clipboard): IClipboardPayload;
export declare function getBlockClipboardData(clipboard: Clipboard, block: Parent, copyType: CopyType): IClipboardPayload;
export declare function writeClipboardData(clipboard: Clipboard, event: ClipboardEvent): void;
