import { default as Content } from '../block/base/content';
import { ITextSelectionState } from '../selection/types';
import { default as Clipboard } from './index';
import { PasteType } from './types';
interface IUrlPaste {
    start: number;
    end: number;
    link: string;
    selection: ITextSelectionState;
}
export declare function getUrlPaste(clipboard: Clipboard, block: Content, text: string, pasteType: PasteType): IUrlPaste | null;
export declare function pasteUrl(clipboard: Clipboard, block: Content, data: IUrlPaste): void;
export {};
