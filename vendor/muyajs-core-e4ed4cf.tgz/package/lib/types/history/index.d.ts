import { JSONOpList } from 'ot-json1';
import { Muya } from '../muya';
import { TSelectionState } from '../selection/types';
import { TState } from '../state/types';
import { Nullable } from '../types';
interface IOptions {
    delay: number;
    maxStack: number;
    userOnly: boolean;
}
interface ISerializableOperation {
    operation: JSONOpList;
    selection: Nullable<TSelectionState>;
    rebuild?: boolean;
}
export interface ISerializedHistory {
    stack: {
        undo: ISerializableOperation[];
        redo: ISerializableOperation[];
    };
    lastRecorded: number;
}
export type TInputKind = 'insert' | 'delete';
export declare function classifyInputKind(inputType: string): Nullable<TInputKind>;
export declare function shouldBreakUndoGroup(prevKind: Nullable<TInputKind>, kind: Nullable<TInputKind>, data: Nullable<string>): boolean;
declare class History {
    private _muya;
    private _options;
    private _lastRecorded;
    private _lastInputKind;
    private _nextSelection;
    private _lastSelection;
    private _stack;
    private get _selection();
    constructor(_muya: Muya, _options?: IOptions);
    private _listen;
    private _change;
    clear(): void;
    getHistory(): ISerializedHistory;
    setHistory(history: ISerializedHistory): void;
    private _copyOperation;
    cutoff(selection?: TSelectionState): void;
    markInputBoundary(inputType: string, data: Nullable<string>): void;
    private _record;
    recordRebuild(op: JSONOpList, prevDoc: readonly TState[], selection: Nullable<TSelectionState>): void;
    canRedo(): boolean;
    redo(): void;
    private _transform;
    canUndo(): boolean;
    undo(): void;
}
export default History;
