import { default as Content } from '../block/base/content';
export interface IAffiliationEntry {
    /** Markdown block type: `p`, `h1`…`h6`, `ul`, `ol`, `li`, `pre`, `figure`, `blockquote`, `hr`. */
    type: string;
    blockName: string;
    alertType?: string;
    canGithubAlerts?: boolean;
    /** Present on list ancestors (`ul` / `ol`): `bullet` | `order` | `task`. */
    listType?: string;
    listItemType?: string;
    isLooseListItem?: boolean;
}
export interface IEndpointBlockInfo {
    blockName: string;
    /** Content-block type — always `span` for a content leaf. */
    type: string;
    functionType?: string;
}
export declare function buildAffiliation(leaf: Content | null): IAffiliationEntry[];
export declare function buildSelectionAffiliation(anchorLeaf: Content | null, focusLeaf: Content | null): IAffiliationEntry[];
export declare function endpointBlockInfo(leaf: Content | null): IEndpointBlockInfo | null;
