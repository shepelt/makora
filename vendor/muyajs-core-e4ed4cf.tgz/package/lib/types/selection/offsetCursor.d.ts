import { ScrollPage } from '../block/scrollPage';
import { TState } from '../state/types';
import { ITextSelectionState } from './types';
export interface IIndexPosition {
    line: number;
    ch: number;
}
export interface IIndexCursor {
    anchor: IIndexPosition | null;
    focus: IIndexPosition | null;
}
export declare function injectSentinels(markdown: string, cursor: IIndexCursor): string | null;
export declare function resolveSentinelCursor(scrollPage: ScrollPage): ITextSelectionState | null;
export declare function injectStateSentinels(state: TState[], selection: ITextSelectionState): TState[] | null;
export declare function locateSentinelOffsets(markdown: string): IIndexCursor | null;
