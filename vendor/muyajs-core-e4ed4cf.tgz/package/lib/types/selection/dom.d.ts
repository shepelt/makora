import { default as Content } from '../block/base/content';
import { IAnchorFocusInfo } from './types';
export declare function isContentDOM(element: HTMLElement): boolean;
export declare function findContentDOM(node: Node | null | undefined): HTMLElement | null;
export declare function resolveEndpoint(node: Node, offset: number): IAnchorFocusInfo | null;
export declare function lineAtPoint(doc: Document, x: number, y: number): {
    block: Content;
    start: number;
    end: number;
} | null;
/**
 * Nearest offset on `block`'s first (`top`) or last (`bottom`) visual line at
 * viewport x `x`; `null` when no caret can be placed there.
 */
export declare function offsetInBlockAtPoint(doc: Document, block: Content, x: number, edge: 'top' | 'bottom'): number | null;
export declare function compareParagraphsOrder(paragraph1: HTMLElement, paragraph2: HTMLElement): number;
export declare function getTextContent(node: Node, blackList?: string[]): string;
export declare function getOffsetOfParagraph(node: Node, paragraph: HTMLElement): number;
export declare function getNodeAndOffset(node: Node, offset: number): {
    node: Node;
    offset: number;
};
export declare function getLegalOffset(node: Node, offset: number): number;
