import { AutoLinkExtensionToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function autoLinkExtension(this: Renderer, { h, block, token }: ISyntaxRenderOptions & {
    token: AutoLinkExtensionToken;
}): import('snabbdom').VNode[];
