import { DelToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export default function del(this: Renderer, options: IContainerRenderOptions & {
    token: DelToken;
}): import('snabbdom').VNode[];
