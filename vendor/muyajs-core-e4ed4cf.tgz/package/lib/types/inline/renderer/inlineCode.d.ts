import { VNode } from 'snabbdom';
import { InlineCodeToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function inlineCode(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: InlineCodeToken;
}): VNode[];
