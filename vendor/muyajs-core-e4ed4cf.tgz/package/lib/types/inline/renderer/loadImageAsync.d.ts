import { ImageMounts } from '../resources/imageMounts';
import { ImageResources } from '../resources/images';
interface IImageRenderHost {
    images: ImageResources;
    mounts: ImageMounts;
    environment: {
        root: HTMLElement;
    };
}
export default function loadImageAsync(this: IImageRenderHost, imageInfo: {
    isUnknownType: boolean;
    src: string;
}, attrs: Record<string, string>, className?: string, imageClass?: string): {
    id: string;
    isSuccess: boolean;
    url?: string;
    width?: number;
    height?: number;
} | {
    id: string;
    isSuccess: undefined;
    url: undefined;
    width: undefined;
    height: undefined;
};
export {};
