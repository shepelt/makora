import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function backlash(this: Renderer, { h, cursor, block, token, outerClass }: ISyntaxRenderOptions): import('snabbdom').VNode[];
