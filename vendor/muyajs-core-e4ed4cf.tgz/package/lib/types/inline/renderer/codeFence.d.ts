import { BeginRuleToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function codeFence(this: Renderer, { h, block, token }: ISyntaxRenderOptions & {
    token: BeginRuleToken;
}): import('snabbdom').VNode[];
