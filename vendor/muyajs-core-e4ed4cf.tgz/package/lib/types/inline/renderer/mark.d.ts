import { MarkToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export default function mark(this: Renderer, options: IContainerRenderOptions & {
    token: MarkToken;
}): import('snabbdom').VNode[];
