import { InlineDiffToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function inlineDiff(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: InlineDiffToken;
}): import('snabbdom').VNode[];
