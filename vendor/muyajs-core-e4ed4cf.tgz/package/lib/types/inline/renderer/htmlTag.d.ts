import { VNode } from 'snabbdom';
import { HTMLTagToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export declare function isLiteralHtml(token: HTMLTagToken): boolean;
export default function htmlTag(this: Renderer, { h, cursor, block, token, outerClass, childNodes, }: IContainerRenderOptions & {
    token: HTMLTagToken;
}): (string | VNode)[];
