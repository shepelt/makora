import { VNode } from 'snabbdom';
import { Token } from '../model/types';
import { default as Renderer } from './index';
import { H } from './types';
export default function lineBreakHighlights(this: Renderer, h: H, token: Token, rStart: number, rEnd: number): (string | VNode)[];
