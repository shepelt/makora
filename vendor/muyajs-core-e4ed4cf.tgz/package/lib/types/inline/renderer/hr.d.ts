import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function hr(this: Renderer, { h, block, token }: ISyntaxRenderOptions): import('snabbdom').VNode[];
