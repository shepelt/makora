import { HTMLTagToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function htmlRuby(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: HTMLTagToken;
}): import('snabbdom').VNode[];
