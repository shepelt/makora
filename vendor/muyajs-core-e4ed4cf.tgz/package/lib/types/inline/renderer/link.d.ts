import { LinkToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export default function link(this: Renderer, { h, cursor, block, token, outerClass, childNodes, }: IContainerRenderOptions & {
    token: LinkToken;
}): (string | import('snabbdom').VNode)[];
