import { Token } from '../model/types';
export declare function hyperlinkProps(href: string, title?: string, target?: string): {
    target?: string | undefined;
    title?: string | undefined;
    href: string;
};
export declare function sourceDataset(token: Token): {
    start: string;
    end: string;
    raw: string;
};
