import { EmojiToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function emoji(this: Renderer, { h, cursor, block, token, outerClass }: ISyntaxRenderOptions & {
    token: EmojiToken;
}): import('snabbdom').VNode[];
