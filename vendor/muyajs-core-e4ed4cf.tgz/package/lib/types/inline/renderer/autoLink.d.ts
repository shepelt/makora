import { AutoLinkToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function autoLink(this: Renderer, { h, cursor, block, token, outerClass }: ISyntaxRenderOptions & {
    token: AutoLinkToken;
}): import('snabbdom').VNode[];
