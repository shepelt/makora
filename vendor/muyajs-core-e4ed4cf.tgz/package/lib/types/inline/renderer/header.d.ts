import { BeginRuleToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function header(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: BeginRuleToken;
}): import('snabbdom').VNode[];
