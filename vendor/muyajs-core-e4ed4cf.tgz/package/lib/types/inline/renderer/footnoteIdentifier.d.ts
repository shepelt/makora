import { FootnoteIdentifierToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function footnoteIdentifier(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: FootnoteIdentifierToken;
}): import('snabbdom').VNode[];
