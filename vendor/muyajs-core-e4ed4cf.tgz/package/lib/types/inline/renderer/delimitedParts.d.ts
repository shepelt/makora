import { ITokenRange } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export declare function delimitedParts(renderer: Renderer, { h, block, token }: ISyntaxRenderOptions, openingLength: number, closingLength?: number, contentRange?: ITokenRange): {
    startMarker: (string | import('snabbdom').VNode)[];
    content: (string | import('snabbdom').VNode)[];
    endMarker: (string | import('snabbdom').VNode)[];
};
