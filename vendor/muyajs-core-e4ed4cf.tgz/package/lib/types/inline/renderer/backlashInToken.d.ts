import { Token } from '../model/types';
import { default as Renderer } from './index';
import { H } from './types';
export default function backlashInToken(this: Renderer, h: H, backlashes: string, outerClass: string, start: number, token: Token): import('snabbdom').VNode[];
