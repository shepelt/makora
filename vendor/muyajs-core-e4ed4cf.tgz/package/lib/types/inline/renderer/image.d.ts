import { VNode } from 'snabbdom';
import { TSelectableImageToken } from '../../utils/image';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function image(this: Renderer, { h, block, token }: ISyntaxRenderOptions & {
    token: TSelectableImageToken;
}): VNode[];
