import { StrongEmToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export default function em(this: Renderer, options: IContainerRenderOptions & {
    token: StrongEmToken;
}): import('snabbdom').VNode[];
