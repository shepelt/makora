import { HardLineBreakToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function hardLineBreak(this: Renderer, { h, token, block, cursor, outerClass }: ISyntaxRenderOptions & {
    token: HardLineBreakToken;
}): import('snabbdom').VNode[];
