import { VNode } from 'snabbdom';
import { DelToken, MarkToken, StrongEmToken } from '../model/types';
import { default as Renderer } from './index';
import { IContainerRenderOptions } from './types';
export default function delEmStrongFac(this: Renderer, type: 'del' | 'mark' | 'em' | 'strong', { h, cursor, block, token, outerClass, childNodes, }: IContainerRenderOptions & {
    token: StrongEmToken | DelToken | MarkToken;
}): VNode[];
