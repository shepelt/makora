import { Token } from '../model/types';
import { default as Renderer } from './index';
import { H, IRenderBlock } from './types';
export default function highlight(this: Renderer, h: H, block: IRenderBlock, rStart: number, rEnd: number, token: Token): (string | import('snabbdom').VNode)[];
