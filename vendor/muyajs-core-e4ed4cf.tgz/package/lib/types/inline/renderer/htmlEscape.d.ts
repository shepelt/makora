import { HTMLEscapeToken } from '../model/types';
import { default as Renderer } from './index';
import { ISyntaxRenderOptions } from './types';
export default function htmlEscape(this: Renderer, { h, cursor, block, token, outerClass, }: ISyntaxRenderOptions & {
    token: HTMLEscapeToken;
}): import('snabbdom').VNode[];
