export interface ICodeSpanMatch {
    end: number;
    markerLength: number;
    closed: boolean;
}
export interface ICodeSpanReader {
    read: (index: number) => ICodeSpanMatch | null;
}
export declare class CodeSpanScanner {
    private _source;
    private _runs;
    private _startsByLength;
    constructor(_source: string);
    read(index: number): ICodeSpanMatch | null;
    /** Child-relative offsets over this index; closers outside [start, end) remain unmatched. */
    view(start: number, end: number): ICodeSpanReader;
    private _closerAfter;
}
export declare function codeSpanContent(source: string): {
    content: string;
    leading: number;
    trailing: number;
};
