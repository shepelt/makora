export declare function matchAt(pattern: RegExp, src: string, index: number): RegExpExecArray | null;
