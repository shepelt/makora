import { IInlineParseOptions } from './types';
export declare function parseInline(src: string, { profile, labels, options, }?: IInlineParseOptions): import('../model/types').Token[];
