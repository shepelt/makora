export interface ILinkTail {
    src: string;
    title: string;
    /** UTF-16 offset of the closing `)`, excluded from the destination/title source. */
    length: number;
}
/**
 * Read the destination and title out of the text a link's or image's `](`
 * opens, with escapes and entity references resolved, or null when it is not a
 * well-formed pair — in which case the whole `[...](...)` run is literal text.
 *
 * The text may run past the link; `length` identifies its closing parenthesis.
 */
export declare function parseSrcAndTitle(text?: string): ILinkTail | null;
