import { IInlineFeatures } from './types';
export declare function resolveInlineFeatures(options?: Partial<IInlineFeatures>): IInlineFeatures;
