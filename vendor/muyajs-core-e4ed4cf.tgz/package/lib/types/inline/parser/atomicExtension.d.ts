import { InlineRules, BACKSLASH_MATH_RULES } from './rules';
import { IInlineFeatures } from './types';
export type AtomicRule = typeof BACKSLASH_MATH_RULES[number][0] | 'inline_math_gfm' | 'inline_math' | 'inline_diff' | 'footnote_identifier' | 'superscript' | 'subscript';
/** Shared recognition for token consumption and structural protection; priority belongs to callers. */
export declare function matchExtension(rule: AtomicRule, source: string, index: number, rules: InlineRules, options: IInlineFeatures, offset?: number): RegExpExecArray | null;
export declare function atomicExtensionLength(source: string, index: number, rules: InlineRules, options: IInlineFeatures, offset?: number): number;
