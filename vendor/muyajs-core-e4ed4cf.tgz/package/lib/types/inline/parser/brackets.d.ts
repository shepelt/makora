import { Labels } from '../model/types';
import { ICodeSpanReader } from './codeSpan';
import { ILinkTail } from './linkDestination';
import { InlineRules } from './rules';
import { IInlineFeatures } from './types';
interface IBracketContent {
    raw: string;
    description: string;
    alt: string;
    backlash: {
        first: string;
        second: string;
    };
}
type InlineMatch = IBracketContent & {
    srcAndTitle: string;
    tail: ILinkTail;
} & ({
    type: 'image';
} | {
    type: 'link';
});
type ReferenceMatch = IBracketContent & {
    label: string;
    isFullLink: boolean;
} & ({
    type: 'reference_image';
} | {
    type: 'reference_link';
});
export type BracketMatch = InlineMatch | ReferenceMatch;
export type ImageMatch = BracketMatch & {
    type: 'image' | 'reference_image';
};
export type LinkMatch = BracketMatch & {
    type: 'link' | 'reference_link';
};
interface IScanContext {
    rules?: InlineRules;
    options?: Partial<IInlineFeatures>;
    offset?: number;
}
export declare class BracketScanner {
    private _matches;
    private _tails;
    private _readProtected;
    constructor(source: string, labels: Labels, codeSpans?: ICodeSpanReader, { rules, options, offset }?: IScanContext);
    read(index: number, end?: number): BracketMatch | null;
    /** HTML pairing must not consume recognized link/image bodies, tails or atomic extensions. */
    protectedEnd(index: number): number;
    private _deactivateLinks;
}
export {};
