import { IDelimiterSpan } from '../../utils/delimiters';
import { HTMLTagToken, ImageToken, Labels, ReferenceImageToken, Token } from '../model/types';
import { BracketScanner } from './brackets';
import { CodeSpanScanner, ICodeSpanReader } from './codeSpan';
import { IBlockProfile } from './profiles';
import { HtmlTagScanner } from './rawHtml';
import { InlineRules } from './rules';
import { SourceWindow } from './sourceWindow';
import { IInlineFeatures } from './types';
export interface IInlineContent {
    source: string;
    position: number;
    token: ImageToken | ReferenceImageToken | HTMLTagToken;
    tokens: Token[];
}
export interface ILexContext {
    window: SourceWindow;
    codeSpans: CodeSpanScanner;
    brackets: BracketScanner;
    htmlTags: HtmlTagScanner;
    inlineContents: IInlineContent[];
}
export interface ILexState {
    parseFrame: (source: string, options: IParseFrameOptions) => Token[];
    codeSpans: ICodeSpanReader;
    context: ILexContext;
    window: SourceWindow;
    src: string;
    pos: number;
    pending: string;
    pendingStartPos: number;
    tokens: Token[];
    delimiterSpans: Map<number, IDelimiterSpan> | null;
    inlineRules: InlineRules;
    labels: Labels;
    options: IInlineFeatures;
    top: boolean;
    allowAutolinks: boolean;
}
export interface IParseFrameOptions {
    inlineRules: InlineRules;
    pos: number;
    top: boolean;
    labels: Labels;
    options: IInlineFeatures;
    delimiterSpans?: Map<number, IDelimiterSpan> | null;
    allowAutolinks?: boolean;
    parentContext?: ILexContext;
    profile: IBlockProfile;
}
export interface IChunkMatch {
    rule: 'inline_math_gfm' | 'mark' | 'inline_diff' | 'emoji' | 'inline_math';
    to: RegExpExecArray;
}
