export declare const WHITELIST_ATTRIBUTES: string[];
export declare function getAttributes(html: string): Record<string, string>;
