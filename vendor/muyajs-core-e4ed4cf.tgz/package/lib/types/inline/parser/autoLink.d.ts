export declare function trimAutoLinkExtent(raw: string): string;
export declare function matchExtendedAutoLink(pattern: RegExp, src: string, index: number, top: boolean): RegExpExecArray | null;
