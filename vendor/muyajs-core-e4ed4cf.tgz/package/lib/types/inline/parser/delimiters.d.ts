import { IDelimiterSpan } from '../../utils/delimiters';
import { Labels } from '../model/types';
import { ICodeSpanReader } from './codeSpan';
import { InlineRules } from './rules';
import { IInlineFeatures } from './types';
import { BracketScanner } from './brackets';
export declare function scanDelimiterSpans(src: string, offset: number, rules: InlineRules, labels: Labels, options: IInlineFeatures, allowAutolinks: boolean, codeSpans?: ICodeSpanReader | undefined, brackets?: BracketScanner): Map<number, IDelimiterSpan>;
