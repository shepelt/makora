import { ITokenizerOptions } from './parser/types';
export declare function tokenizer(source: string, options?: ITokenizerOptions): import('./model/types').Token[];
