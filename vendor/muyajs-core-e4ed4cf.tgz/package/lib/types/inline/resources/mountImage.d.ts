import { ILoadedImage } from './images';
export declare function mountImage(imageText: HTMLElement, result: ILoadedImage, attrs: Record<string, string>, className?: string, imageClass?: string): void;
