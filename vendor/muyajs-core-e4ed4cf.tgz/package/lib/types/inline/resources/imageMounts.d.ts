import { ILoadedImage } from './images';
interface IImageBinding {
    scope: HTMLElement;
    apply: (placeholder: HTMLElement, result: ILoadedImage) => void;
}
/** Pending callbacks follow their placeholders within one editor, including synchronous DOM moves. */
export declare class ImageMounts {
    private _root;
    private _bindings;
    private _observer;
    private _pruneScheduled;
    private _disposed;
    constructor(_root: HTMLElement);
    get size(): number;
    /** The returned ID must be mounted in scope before the next microtask. */
    watch(scope: HTMLElement, request: Promise<ILoadedImage | null>, apply: IImageBinding['apply']): string;
    private _placeholder;
    private _prune;
    private _disconnectIfIdle;
    clear(): void;
    dispose(): void;
}
export {};
