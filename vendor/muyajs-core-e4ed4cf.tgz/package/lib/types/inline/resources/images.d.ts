export interface ILoadedImage {
    readonly id: string;
    readonly isSuccess: boolean;
    readonly url?: string;
    readonly width?: number;
    readonly height?: number;
}
/** Resource identity is independent of DOM occurrences; failed loads remain retryable. */
export declare class ImageResources {
    private _states;
    private _previews;
    private _disposed;
    get size(): number;
    get(src: string): ILoadedImage | undefined;
    getPreview(src: string): string | undefined;
    setPreview(src: string, preview: string): void;
    request(src: string, detectContentType: boolean): Promise<ILoadedImage | null>;
    invalidate(): void;
    dispose(): void;
}
