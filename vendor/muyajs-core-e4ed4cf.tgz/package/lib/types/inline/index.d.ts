import { default as Format } from '../block/base/format';
import { Muya } from '../muya';
import { IRenderCursor } from '../selection/types';
import { IParagraphState } from '../state/types';
import { IHighlight, Labels } from './model/types';
import { default as Renderer } from './renderer';
declare class InlineEngine {
    muya: Muya;
    private _labels;
    get labels(): Labels;
    renderer: Renderer;
    private _references;
    constructor(muya: Muya);
    private _tokenizer;
    /** Invalidates pending and completed loads before repainting all image occurrences. */
    invalidateImageCache(): void;
    setImagePreview(src: string, preview: string): void;
    dispose(): void;
    patch(block: Format, cursor?: IRenderCursor, highlights?: IHighlight[]): void;
    collectReferenceDefinitions(): Labels;
    getLabelInfo(blockOrState: Pick<IParagraphState, 'text'>): {
        label: null;
        info: null;
    } | {
        label: string;
        info: {
            href: string;
            title: string;
        };
    };
}
export default InlineEngine;
